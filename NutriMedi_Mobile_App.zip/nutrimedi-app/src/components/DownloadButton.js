import React, { useState } from 'react';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { Btn, useToast } from './UI';
import { fetchDigitalPdfBase64 } from '../api';

// Downloads a purchased digital PDF through the existing /api/digital-download endpoint, then opens the share/save sheet.
export default function DownloadButton({ item }) {
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  const run = async () => {
    setBusy(true);
    try {
      const b64 = await fetchDigitalPdfBase64(item.token);
      if (!b64) throw new Error('The file was empty.');
      const safe = String(item.name || item.productId || 'NutriMedi').replace(/[^A-Za-z0-9_-]+/g, '_').slice(0, 60);
      const uri = FileSystem.cacheDirectory + 'NutriMedi_' + safe + '.pdf';
      await FileSystem.writeAsStringAsync(uri, b64, { encoding: FileSystem.EncodingType.Base64 });
      if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri, { mimeType: 'application/pdf', dialogTitle: item.name, UTI: 'com.adobe.pdf' });
      else toast.show('Saved to app storage');
    } catch (e) { toast.show(e.message || 'Download failed'); }
    finally { setBusy(false); }
  };
  return <Btn title={'Download: ' + (item.name || 'PDF')} icon="download" onPress={run} loading={busy} variant="cool" small />;
}
