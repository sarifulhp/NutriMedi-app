import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'nm_saved_articles_v1';
const Ctx = createContext(null);

// Saved articles live on this device only (the existing backend has no bookmark endpoint).
export function BookmarksProvider({ children }) {
  const [items, setItems] = useState([]);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    AsyncStorage.getItem(KEY).then((raw) => { try { const v = JSON.parse(raw || '[]'); if (Array.isArray(v)) setItems(v); } catch (_) {} }).finally(() => setReady(true));
  }, []);
  useEffect(() => { if (ready) AsyncStorage.setItem(KEY, JSON.stringify(items)).catch(() => {}); }, [items, ready]);

  const isSaved = useCallback((slug) => items.some((i) => i.slug === slug), [items]);
  const toggle = useCallback((a) => setItems((cur) => (cur.some((i) => i.slug === a.slug)
    ? cur.filter((i) => i.slug !== a.slug)
    : [{ slug: a.slug, title: a.title, category: a.category, excerpt: a.excerpt, cover: a.cover, author: a.author, time: a.time, mins: a.mins, theme: a.theme, bn: a.bn }, ...cur])), []);
  const value = useMemo(() => ({ items, isSaved, toggle }), [items, isSaved, toggle]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export const useBookmarks = () => useContext(Ctx);
