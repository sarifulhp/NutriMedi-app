// Razorpay checkout (the same payment provider the website uses).
// react-native-razorpay is a native module, so payments work in a development / release build,
// not inside Expo Go. We load it lazily so the rest of the app still runs in Expo Go.
export async function openRazorpay(options) {
  let Checkout;
  try {
    // eslint-disable-next-line global-require
    const mod = require('react-native-razorpay');
    Checkout = mod.default || mod;
  } catch (_) { Checkout = null; }
  if (!Checkout || typeof Checkout.open !== 'function') {
    throw new Error('Payments need the installed NutriMedi app build (not Expo Go). Nothing was charged.');
  }
  try {
    const res = await Checkout.open({ currency: 'INR', name: 'NutriMedi', theme: { color: '#087F78' }, ...options });
    if (!res || !res.razorpay_payment_id || !res.razorpay_signature) throw new Error('Payment was not completed.');
    return res;
  } catch (e) {
    const desc = String((e && (e.description || e.message)) || '');
    if (e && (e.code === 0 || e.code === 2 || /cancel/i.test(desc))) throw new Error('Payment cancelled. Nothing was charged.');
    throw new Error(desc || 'Payment failed. Please try again.');
  }
}
