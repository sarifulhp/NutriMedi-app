import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Btn, ErrorBox, RemoteImage, Skeleton, money, useToast } from '../components/UI';
import { useData } from '../context/DataContext';
import { useCart } from '../context/CartContext';
import { catTheme } from '../utils/articleFormat';
import { colors, radius, themes } from '../theme';

export default function ProductScreen({ route, navigation }) {
  const insets = useSafeAreaInsets();
  const { products, loadProducts } = useData();
  const cart = useCart();
  const toast = useToast();
  const [qty, setQty] = useState(1);
  useEffect(() => { loadProducts(); }, [loadProducts]);
  const p = products.items.find((x) => x.id === route.params.id);

  const Back = (
    <Pressable onPress={() => navigation.goBack()} accessibilityRole="button" accessibilityLabel="Back" style={[styles.back, { top: insets.top + 10 }]}><Ionicons name="arrow-back" size={22} color="#fff" /></Pressable>
  );
  if (!p) {
    return (
      <View style={styles.root}>{Back}
        <View style={{ paddingTop: insets.top + 80, padding: 20 }}>
          {products.error ? <ErrorBox message={products.error} onRetry={() => loadProducts(true)} /> : products.loading ? <Skeleton height={320} radiusPx={28} /> : <ErrorBox message="This product is no longer available." />}
        </View>
      </View>
    );
  }
  const th = themes[catTheme(p.category)];
  const out = p.stock !== null && p.stock <= 0;
  const max = Math.min(20, p.stock === null ? 20 : p.stock);
  const inCart = (cart.lines.find((l) => l.product.id === p.id) || {}).quantity || 0;

  return (
    <View style={styles.root}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 130 }}>
        <RemoteImage uri={p.image} grad={th.grad} icon="bag-handle" style={{ width: '100%', aspectRatio: 1 }} />
        <View style={styles.sheet}>
          <View style={[styles.tag, { backgroundColor: th.soft }]}><Text style={[styles.tagText, { color: th.a }]}>{p.category}</Text></View>
          {p.type === 'digital' ? <View style={[styles.tag, { backgroundColor: colors.softPurple, marginLeft: 8 }]}><Text style={[styles.tagText, { color: colors.purple }]}>Digital PDF</Text></View> : null}
          <Text style={styles.name}>{p.name}</Text>
          <Text style={styles.price}>{money(p.price)}</Text>
          {out ? <Text style={styles.out}>Currently out of stock</Text> : p.stock !== null && p.stock <= 5 ? <Text style={styles.low}>Only {p.stock} left</Text> : null}
          {p.description ? <Text style={styles.desc}>{p.description}</Text> : null}
          {p.type === 'digital' ? <Text style={styles.fine}>Digital products need online payment and are available to download after your order is verified.</Text> : null}
        </View>
      </ScrollView>
      {Back}
      <View style={[styles.bar, { paddingBottom: insets.bottom + 12 }]}>
        {!out ? (
          <View style={styles.stepper}>
            <Pressable onPress={() => setQty((q) => Math.max(1, q - 1))} hitSlop={6} accessibilityLabel="Decrease quantity" style={styles.stepBtn}><Ionicons name="remove" size={20} color={colors.navy} /></Pressable>
            <Text style={styles.qty}>{qty}</Text>
            <Pressable onPress={() => setQty((q) => Math.min(max, q + 1))} hitSlop={6} accessibilityLabel="Increase quantity" style={styles.stepBtn}><Ionicons name="add" size={20} color={colors.navy} /></Pressable>
          </View>
        ) : null}
        <Btn title={out ? 'Out of stock' : inCart ? 'Add more' : 'Add to cart'} icon="bag-add" disabled={out} onPress={() => { cart.add(p, qty); toast.show('Added to cart'); }} style={{ flex: 1 }} />
        {inCart > 0 ? <Btn title="Cart" variant="navy" onPress={() => navigation.navigate('Cart')} style={{ marginLeft: 8 }} full={false} /> : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  back: { position: 'absolute', left: 16, width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(20,43,89,.6)', alignItems: 'center', justifyContent: 'center' },
  sheet: { marginTop: -28, backgroundColor: colors.bg, borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 22, flexDirection: 'row', flexWrap: 'wrap' },
  tag: { borderRadius: 999, paddingHorizontal: 13, paddingVertical: 6 },
  tagText: { fontWeight: '800', fontSize: 12.5 },
  name: { width: '100%', color: colors.navy, fontSize: 27, fontWeight: '800', lineHeight: 33, letterSpacing: -0.5, marginTop: 14 },
  price: { width: '100%', color: colors.teal, fontSize: 28, fontWeight: '800', marginTop: 8 },
  out: { width: '100%', color: colors.danger, fontWeight: '800', marginTop: 8 },
  low: { width: '100%', color: colors.orange, fontWeight: '800', marginTop: 8 },
  desc: { width: '100%', color: colors.text, fontSize: 16, lineHeight: 25, marginTop: 16 },
  fine: { width: '100%', color: colors.muted, fontSize: 13, lineHeight: 19, marginTop: 14 },
  bar: { position: 'absolute', left: 0, right: 0, bottom: 0, flexDirection: 'row', alignItems: 'center', padding: 14, backgroundColor: '#fff', borderTopLeftRadius: 26, borderTopRightRadius: 26, shadowColor: '#142B59', shadowOpacity: 0.14, shadowRadius: 18, shadowOffset: { width: 0, height: -6 }, elevation: 12 },
  stepper: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.softNavy, borderRadius: 999, marginRight: 10 },
  stepBtn: { width: 44, height: 48, alignItems: 'center', justifyContent: 'center' },
  qty: { minWidth: 26, textAlign: 'center', fontWeight: '800', fontSize: 17, color: colors.navy }
});
