import { API_BASE } from '../config';

export class ApiError extends Error {
  constructor(message, status, data) { super(message); this.status = status; this.data = data; }
}

const TIMEOUT_MS = 30000;

// Thin wrapper over fetch for the existing NutriMedi Vercel API (/api/<endpoint>).
// credentials:'include' lets the OS cookie jar keep the admin session cookie, exactly like the website.
export async function request(path, { method = 'GET', body, headers = {}, timeout = TIMEOUT_MS, raw = false } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const res = await fetch(API_BASE + path, {
      method,
      credentials: 'include',
      headers: { Accept: 'application/json', ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...headers },
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: controller.signal
    });
    if (raw) return res;
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.success === false || data.ok === false) {
      throw new ApiError(data.error || data.message || 'Something went wrong. Please try again.', res.status, data);
    }
    return data;
  } catch (e) {
    if (e instanceof ApiError) throw e;
    if (e && e.name === 'AbortError') throw new ApiError('The request took too long. Please check your connection and try again.', 0);
    throw new ApiError('No internet connection or the server is unreachable. Please try again.', 0);
  } finally {
    clearTimeout(timer);
  }
}
