import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Btn, Card, Chip, Empty, ErrorBox, Notice, PageHeader, SearchBar, Skeleton, money, useToast } from '../components/UI';
import { adminApi } from '../api';
import { colors, radius } from '../theme';

const B_STATUS = ['Pending', 'Confirmed', 'Cancelled'];
const O_STATUS = ['processing', 'packed', 'shipped', 'delivered', 'cancelled'];

export default function AdminHomeScreen({ navigation }) {
  const toast = useToast();
  const [tab, setTab] = useState('appointments');
  const [state, setState] = useState({ bookings: [], orders: [], articles: [], loading: true, error: '' });
  const [q, setQ] = useState('');
  const [expired, setExpired] = useState(false);

  const fail = useCallback((e) => {
    if (e.status === 401) { setExpired(true); return; }
    toast.show(e.message || 'Request failed');
  }, [toast]);

  const load = useCallback(async () => {
    setState((s) => ({ ...s, loading: true, error: '' }));
    try {
      const [bookings, orders, articles] = await Promise.all([adminApi.bookings(), adminApi.orders(), adminApi.articles()]);
      setState({ bookings, orders, articles, loading: false, error: '' });
    } catch (e) {
      if (e.status === 401) { setExpired(true); setState((s) => ({ ...s, loading: false })); return; }
      setState((s) => ({ ...s, loading: false, error: e.message }));
    }
  }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => navigation.addListener('focus', () => { if (!state.loading) load(); }), [navigation]); // eslint-disable-line

  const signOut = async () => { try { await adminApi.logout(); } catch (_) {} navigation.popToTop(); };

  const n = q.trim().toLowerCase();
  const bookings = useMemo(() => state.bookings.filter((b) => !n || JSON.stringify(b).toLowerCase().includes(n)), [state.bookings, n]);
  const orders = useMemo(() => state.orders.filter((o) => !n || JSON.stringify(o).toLowerCase().includes(n)), [state.orders, n]);
  const articles = useMemo(() => state.articles.filter((a) => !n || (a.title + ' ' + a.category).toLowerCase().includes(n)), [state.articles, n]);

  if (expired) {
    return (
      <View style={styles.root}>
        <PageHeader icon="shield-checkmark" title="Admin" colorsOverride={['#142B59', '#7657D6']} />
        <View style={{ padding: 20 }}><Empty icon="time-outline" title="Session expired" message="Admin sessions last 30 minutes. Please sign in again." action="Sign in" onAction={() => navigation.replace('AdminLogin')} /></View>
      </View>
    );
  }

  const counts = {
    pending: state.bookings.filter((b) => String(b.Status || 'Pending').toLowerCase() === 'pending').length,
    paid: state.orders.length,
    published: state.articles.filter((a) => String(a.status).toLowerCase() === 'published').length,
    drafts: state.articles.filter((a) => String(a.status).toLowerCase() !== 'published').length
  };

  const setBooking = async (b, status) => {
    try { await adminApi.setBookingStatus(b['Booking Serial'], status); setState((s) => ({ ...s, bookings: s.bookings.map((x) => (x === b ? { ...x, Status: status } : x)) })); toast.show('Appointment ' + status.toLowerCase()); } catch (e) { fail(e); }
  };
  const setOrder = async (o, status) => {
    try { await adminApi.setOrderStatus(o.order_id, status); setState((s) => ({ ...s, orders: s.orders.map((x) => (x === o ? { ...x, order_status: status } : x)) })); toast.show('Order marked ' + status); } catch (e) { fail(e); }
  };
  const togglePublish = async (a) => {
    const pub = String(a.status).toLowerCase() === 'published';
    try { await (pub ? adminApi.unpublishArticle(a.id) : adminApi.publishArticle(a.id)); toast.show(pub ? 'Article unpublished' : 'Article published'); load(); } catch (e) { fail(e); }
  };
  const del = (a) => Alert.alert('Delete article', `Delete “${a.title}”? This cannot be undone.`, [{ text: 'Cancel', style: 'cancel' }, { text: 'Delete', style: 'destructive', onPress: async () => { try { await adminApi.deleteArticle(a.id); toast.show('Article deleted'); load(); } catch (e) { fail(e); } } }]);

  const header = (
    <View>
      <PageHeader icon="shield-checkmark" title="Admin dashboard" subtitle="Appointments, store orders and articles." colorsOverride={['#142B59', '#7657D6']}
        right={<Pressable onPress={signOut} accessibilityRole="button" accessibilityLabel="Sign out of admin" style={styles.out}><Ionicons name="log-out-outline" size={22} color="#fff" /></Pressable>} />
      <View style={styles.stats}>
        {[['Pending', counts.pending, colors.orange], ['Orders', counts.paid, colors.purple], ['Published', counts.published, colors.teal], ['Drafts', counts.drafts, colors.pink]].map(([l, v, c]) => (
          <View key={l} style={[styles.stat, { borderTopColor: c }]}><Text style={styles.statNum}>{v}</Text><Text style={styles.statLabel}>{l}</Text></View>
        ))}
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 12 }}>
        <Chip label="Appointments" active={tab === 'appointments'} onPress={() => setTab('appointments')} count={state.bookings.length} />
        <Chip label="Orders" active={tab === 'orders'} onPress={() => setTab('orders')} count={state.orders.length} />
        <Chip label="Articles" active={tab === 'articles'} onPress={() => setTab('articles')} count={state.articles.length} />
      </ScrollView>
      <View style={{ paddingHorizontal: 16, marginBottom: 12 }}>
        <SearchBar value={q} onChangeText={setQ} placeholder={tab === 'articles' ? 'Search articles…' : tab === 'orders' ? 'Search orders…' : 'Search name, serial, phone…'} />
        {tab === 'articles' ? <Btn title="New article" icon="add-circle" onPress={() => navigation.navigate('AdminArticle', { article: null })} style={{ marginTop: 12 }} small /> : null}
      </View>
    </View>
  );

  const data = tab === 'appointments' ? bookings : tab === 'orders' ? orders : articles;
  let empty = null;
  if (state.loading) empty = <View style={{ padding: 16, gap: 12 }}><Skeleton height={130} radiusPx={22} /><Skeleton height={130} radiusPx={22} /></View>;
  else if (state.error) empty = <ErrorBox message={state.error} onRetry={load} />;
  else empty = <Empty icon="file-tray-outline" title="Nothing here yet" message={n ? 'No records match your search.' : 'Records will appear here.'} />;

  return (
    <View style={styles.root}>
      <FlatList
        data={state.loading || state.error ? [] : data}
        keyExtractor={(x, i) => String(x['Booking Serial'] || x.order_id || x.id || i)}
        ListHeaderComponent={header}
        ListEmptyComponent={empty}
        refreshing={state.loading && !!state.bookings.length}
        onRefresh={load}
        contentContainerStyle={{ paddingBottom: 60 }}
        keyboardShouldPersistTaps="handled"
        renderItem={({ item }) => (
          <View style={{ paddingHorizontal: 16, marginBottom: 14 }}>
            {tab === 'appointments' ? <BookingCard b={item} onStatus={setBooking} />
              : tab === 'orders' ? <OrderCard o={item} onStatus={setOrder} />
              : <ArticleRow a={item} onEdit={() => navigation.navigate('AdminArticle', { article: item })} onPublish={() => togglePublish(item)} onDelete={() => del(item)} />}
          </View>
        )}
      />
    </View>
  );
}

function StatusRow({ options, current, onPick, upper }) {
  return (
    <View style={styles.statusRow}>
      {options.map((s) => {
        const on = String(current || '').toLowerCase() === s.toLowerCase();
        return (
          <Pressable key={s} disabled={on} onPress={() => onPick(s)} accessibilityRole="button" accessibilityState={{ selected: on }} style={[styles.sBtn, on && styles.sBtnOn]}>
            <Text style={[styles.sText, on && { color: '#fff' }]}>{upper ? s.charAt(0).toUpperCase() + s.slice(1) : s}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

function BookingCard({ b, onStatus }) {
  const status = b.Status || 'Pending';
  return (
    <Card style={{ padding: 16 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <View style={styles.serial}><Text style={styles.serialNo}>{String(b.Serial_Number || '—').padStart(3, '0')}</Text></View>
        <View style={{ flex: 1, marginLeft: 12 }}>
          <Text style={styles.h}>{b['Patient Name'] || '—'}</Text>
          <Text style={styles.sub}>{b.Phone || ''}{b.Email ? ' · ' + b.Email : ''}</Text>
          <Text style={styles.sub}>{b.Service || ''}</Text>
          <Text style={styles.sub}>{b['Preferred Date'] || ''} · {b['Consultation Method'] || ''}</Text>
        </View>
      </View>
      {b.Message || b['Message'] ? <Text style={styles.msg}>{b.Message || b['Message']}</Text> : null}
      <StatusRow options={B_STATUS} current={status} onPick={(s) => onStatus(b, s)} />
    </Card>
  );
}

function OrderCard({ o, onStatus }) {
  const items = Array.isArray(o.items) ? o.items : [];
  return (
    <Card style={{ padding: 16 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={[styles.h, { flex: 1 }]} numberOfLines={1}>{o.order_id}</Text>
        <Text style={styles.total}>{o.total !== undefined ? money(o.total) : ''}</Text>
      </View>
      <Text style={styles.sub}>{o.customer_name} · {o.phone}</Text>
      <Text style={styles.sub}>{o.address}{o.pincode ? ' – ' + o.pincode : ''}</Text>
      {items.map((it, i) => <Text key={i} style={styles.sub}>• {it.quantity || it.Quantity || 1} × {it.product_name || it.name || it.productId || 'Item'}</Text>)}
      <Text style={[styles.sub, { marginTop: 6 }]}>Payment: <Text style={{ fontWeight: '800', color: colors.navy }}>{o.payment_status || '—'}</Text></Text>
      <StatusRow options={O_STATUS} current={o.order_status} onPick={(s) => onStatus(o, s)} upper />
    </Card>
  );
}

function ArticleRow({ a, onEdit, onPublish, onDelete }) {
  const pub = String(a.status).toLowerCase() === 'published';
  return (
    <Card style={{ padding: 16 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <View style={[styles.badge, { backgroundColor: pub ? colors.softSuccess : colors.softOrange }]}><Text style={[styles.badgeText, { color: pub ? colors.success : '#9A4A12' }]}>{pub ? 'Published' : 'Draft'}</Text></View>
        <Text style={styles.sub}>{a.category}</Text>
      </View>
      <Text style={[styles.h, { marginTop: 10 }]} numberOfLines={3}>{a.title}</Text>
      <View style={{ flexDirection: 'row', gap: 8, marginTop: 14 }}>
        <Btn title="Edit" icon="create-outline" variant="outline" onPress={onEdit} small style={{ flex: 1 }} />
        <Btn title={pub ? 'Unpublish' : 'Publish'} icon={pub ? 'eye-off-outline' : 'rocket-outline'} variant={pub ? 'outline' : 'cool'} onPress={onPublish} small style={{ flex: 1 }} />
        <Pressable onPress={onDelete} accessibilityRole="button" accessibilityLabel={'Delete ' + a.title} style={styles.trash}><Ionicons name="trash-outline" size={20} color={colors.danger} /></Pressable>
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  out: { width: 46, height: 46, borderRadius: 15, backgroundColor: 'rgba(255,255,255,.18)', alignItems: 'center', justifyContent: 'center' },
  stats: { flexDirection: 'row', gap: 10, paddingHorizontal: 16, marginTop: 16 },
  stat: { flex: 1, backgroundColor: '#fff', borderRadius: radius.md, paddingVertical: 12, alignItems: 'center', borderTopWidth: 5, elevation: 2, shadowColor: '#142B59', shadowOpacity: 0.08, shadowRadius: 8, shadowOffset: { width: 0, height: 3 } },
  statNum: { color: colors.navy, fontSize: 22, fontWeight: '800' },
  statLabel: { color: colors.muted, fontSize: 11.5, fontWeight: '600' },
  h: { color: colors.navy, fontWeight: '800', fontSize: 16, lineHeight: 22 },
  sub: { color: colors.muted, fontSize: 13.5, marginTop: 2, lineHeight: 19 },
  msg: { color: colors.text, fontSize: 13.5, marginTop: 10, backgroundColor: colors.softNavy, padding: 10, borderRadius: 12 },
  total: { color: colors.teal, fontWeight: '800', fontSize: 17 },
  serial: { width: 58, height: 58, borderRadius: 17, backgroundColor: colors.softPurple, alignItems: 'center', justifyContent: 'center' },
  serialNo: { color: colors.purple, fontWeight: '800', fontSize: 20 },
  statusRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 14 },
  sBtn: { borderRadius: 999, borderWidth: 1.5, borderColor: colors.line, paddingHorizontal: 14, paddingVertical: 9, backgroundColor: '#fff', minHeight: 40, justifyContent: 'center' },
  sBtnOn: { backgroundColor: colors.navy, borderColor: colors.navy },
  sText: { color: colors.navy, fontWeight: '800', fontSize: 13 },
  badge: { borderRadius: 999, paddingHorizontal: 12, paddingVertical: 5 },
  badgeText: { fontWeight: '800', fontSize: 12 },
  trash: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.softDanger, alignItems: 'center', justifyContent: 'center' }
});
