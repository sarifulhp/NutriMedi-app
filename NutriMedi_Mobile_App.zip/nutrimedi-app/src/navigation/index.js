import React from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import HomeScreen from '../screens/HomeScreen';
import ArticlesScreen from '../screens/ArticlesScreen';
import ArticleScreen from '../screens/ArticleScreen';
import AppointmentScreen from '../screens/AppointmentScreen';
import StoreScreen from '../screens/StoreScreen';
import ProductScreen from '../screens/ProductScreen';
import CartScreen from '../screens/CartScreen';
import CheckoutScreen from '../screens/CheckoutScreen';
import AccountScreen from '../screens/AccountScreen';
import MoreScreen from '../screens/MoreScreen';
import AdminLoginScreen from '../screens/AdminLoginScreen';
import AdminHomeScreen from '../screens/AdminHomeScreen';
import AdminArticleScreen from '../screens/AdminArticleScreen';
import { useCart } from '../context/CartContext';
import { colors } from '../theme';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const TABS = {
  Home: ['home', 'home-outline', 'Home'],
  Articles: ['book', 'book-outline', 'Articles'],
  Appointment: ['calendar', 'calendar-outline', 'Appointment'],
  Store: ['bag-handle', 'bag-handle-outline', 'Store'],
  Account: ['person', 'person-outline', 'Account']
};

function Tabs() {
  const insets = useSafeAreaInsets();
  const cart = useCart();
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.teal,
        tabBarInactiveTintColor: '#8A97B3',
        tabBarLabelStyle: { fontSize: 11, fontWeight: '700', marginBottom: Platform.OS === 'android' ? 6 : 0 },
        tabBarStyle: { height: 62 + insets.bottom, paddingTop: 8, paddingBottom: insets.bottom, backgroundColor: '#fff', borderTopWidth: 0, borderTopLeftRadius: 26, borderTopRightRadius: 26, position: 'absolute', shadowColor: '#142B59', shadowOpacity: 0.14, shadowRadius: 18, shadowOffset: { width: 0, height: -6 }, elevation: 16 },
        tabBarIcon: ({ focused, color }) => {
          const [on, off] = TABS[route.name];
          return (
            <View style={focused ? styles.pillOn : styles.pill}>
              <Ionicons name={focused ? on : off} size={22} color={color} />
            </View>
          );
        },
        tabBarAccessibilityLabel: TABS[route.name][2]
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Articles" component={ArticlesScreen} />
      <Tab.Screen name="Appointment" component={AppointmentScreen} />
      <Tab.Screen name="Store" component={StoreScreen} options={{ tabBarBadge: cart.count > 0 ? cart.count : undefined, tabBarBadgeStyle: { backgroundColor: colors.orange, color: '#fff', fontWeight: '800' } }} />
      <Tab.Screen name="Account" component={AccountScreen} />
    </Tab.Navigator>
  );
}

const navTheme = { ...DefaultTheme, colors: { ...DefaultTheme.colors, background: colors.bg, card: '#fff', text: colors.navy, primary: colors.teal, border: colors.line } };

// Deep links: nutrimedi://articles/<slug> opens the article reader.
const linking = {
  prefixes: ['nutrimedi://'],
  config: { screens: { Article: 'articles/:slug', Tabs: { screens: { Articles: 'articles', Store: 'store', Appointment: 'appointment', Account: 'account', Home: '' } } } }
};

export default function Navigation() {
  return (
    <NavigationContainer theme={navTheme} linking={linking}>
      <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_right' }}>
        <Stack.Screen name="Tabs" component={Tabs} />
        <Stack.Screen name="Article" component={ArticleScreen} />
        <Stack.Screen name="Product" component={ProductScreen} />
        <Stack.Screen name="Cart" component={CartScreen} />
        <Stack.Screen name="Checkout" component={CheckoutScreen} />
        <Stack.Screen name="More" component={MoreScreen} options={{ presentation: 'modal', animation: 'slide_from_bottom' }} />
        <Stack.Screen name="AdminLogin" component={AdminLoginScreen} options={{ presentation: 'modal', animation: 'slide_from_bottom' }} />
        <Stack.Screen name="AdminHome" component={AdminHomeScreen} />
        <Stack.Screen name="AdminArticle" component={AdminArticleScreen} options={{ presentation: 'modal', animation: 'slide_from_bottom' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  pill: { paddingHorizontal: 16, paddingVertical: 4, borderRadius: 999 },
  pillOn: { paddingHorizontal: 16, paddingVertical: 4, borderRadius: 999, backgroundColor: colors.softTeal }
});
