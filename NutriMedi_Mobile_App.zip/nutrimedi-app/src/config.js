// Single place that decides which backend the app talks to.
// It is the same Vercel deployment that serves https://www.nutrimedi.in
export const API_BASE = (process.env.EXPO_PUBLIC_API_BASE || 'https://www.nutrimedi.in').replace(/\/+$/, '');
export const SITE_URL = 'https://www.nutrimedi.in';
export const CONTACT = {
  email: 'nutrimedi.in@gmail.com',
  phone: '+918900490271',
  phoneLabel: '+91 8900490271',
  whatsapp: 'https://wa.me/918900490271',
  address: 'Balutola, Raikhadighi, Gazole, Malda, West Bengal 732102, India'
};
export const POLICIES = [
  { title: 'Privacy Policy', path: '/privacy-policy.html' },
  { title: 'Terms & Conditions', path: '/terms.html' },
  { title: 'Refund & Cancellation', path: '/refund-policy.html' },
  { title: 'Shipping & Delivery', path: '/shipping-policy.html' },
  { title: 'Booking Policy', path: '/booking-policy.html' }
];
export const SERVICES = [
  { id: 'personalized-nutrition', label: 'Personalized Nutrition', icon: 'nutrition-outline' },
  { id: 'weight-management', label: 'Weight Management', icon: 'scale-outline' },
  { id: 'family-nutrition', label: 'Family Nutrition', icon: 'people-outline' },
  { id: 'sports-nutrition', label: 'Sports Nutrition', icon: 'barbell-outline' }
];
export const SLOTS = [
  { id: 'morning', title: 'Morning', time: '7:00 AM – 9:00 AM', serials: 'Serial 01–10', icon: 'sunny-outline' },
  { id: 'evening', title: 'Evening', time: '5:00 PM – 9:00 PM', serials: 'Serial 11–50', icon: 'moon-outline' }
];
