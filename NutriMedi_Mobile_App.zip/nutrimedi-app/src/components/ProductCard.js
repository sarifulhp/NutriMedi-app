import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { RemoteImage, money } from './UI';
import { catTheme } from '../utils/articleFormat';
import { colors, gradients, radius, shadow, themes } from '../theme';

export function ProductCard({ p, onPress, onAdd, style }) {
  const th = themes[catTheme(p.category)];
  const out = p.stock !== null && p.stock <= 0;
  return (
    <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel={`${p.name}, ${money(p.price)}`} style={({ pressed }) => [styles.card, shadow.md, pressed && { transform: [{ scale: 0.985 }] }, style]}>
      <View>
        <RemoteImage uri={p.image} grad={th.grad} icon="bag-handle" style={styles.img} />
        {p.badge ? <LinearGradient colors={gradients.warm} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.badge}><Text style={styles.badgeText}>{p.badge}</Text></LinearGradient> : null}
        {out ? <View style={styles.out}><Text style={styles.outText}>Out of stock</Text></View> : null}
      </View>
      <View style={{ padding: 14, flex: 1 }}>
        <Text numberOfLines={1} style={[styles.cat, { color: th.a }]}>{p.category.toUpperCase()}</Text>
        <Text numberOfLines={2} style={styles.name}>{p.name}</Text>
        <View style={styles.bottom}>
          <Text style={styles.price}>{money(p.price)}</Text>
          <Pressable onPress={onAdd} disabled={out} hitSlop={8} accessibilityRole="button" accessibilityLabel={`Add ${p.name} to cart`} style={[styles.add, out && { opacity: 0.4 }]}>
            <LinearGradient colors={gradients.warm} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.addIn}><Ionicons name="add" size={22} color="#fff" /></LinearGradient>
          </Pressable>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: '#fff', borderRadius: radius.lg, overflow: 'hidden', flex: 1 },
  img: { width: '100%', aspectRatio: 1 },
  badge: { position: 'absolute', left: 10, top: 10, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4 },
  badgeText: { color: '#fff', fontWeight: '800', fontSize: 11 },
  out: { position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(20,43,89,.82)', paddingVertical: 6, alignItems: 'center' },
  outText: { color: '#fff', fontWeight: '800', fontSize: 12 },
  cat: { fontSize: 11, fontWeight: '800', letterSpacing: 0.6 },
  name: { color: colors.navy, fontSize: 15.5, fontWeight: '800', lineHeight: 20, marginTop: 3, minHeight: 40 },
  bottom: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 'auto', paddingTop: 10 },
  price: { color: colors.teal, fontSize: 18, fontWeight: '800' },
  add: { borderRadius: 999, overflow: 'hidden' },
  addIn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }
});
