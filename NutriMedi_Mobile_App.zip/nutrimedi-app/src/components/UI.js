import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Animated, Image, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, gradients, radius, shadow } from '../theme';

// ---------------------------------------------------------------- screen containers
export function Screen({ children, scroll = true, onRefresh, refreshing = false, contentStyle, header, bottomPad = 24, keyboard = false }) {
  const insets = useSafeAreaInsets();
  if (!scroll) return <View style={[s.screen, { paddingTop: header ? 0 : insets.top }]}>{header}{children}</View>;
  return (
    <View style={s.screen}>
      <ScrollView
        contentContainerStyle={[{ paddingBottom: bottomPad }, contentStyle]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode={keyboard ? 'on-drag' : 'none'}
        refreshControl={onRefresh ? <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.teal} colors={[colors.teal]} /> : undefined}
      >
        {header}
        {children}
      </ScrollView>
    </View>
  );
}

// Gradient page header used on the tab screens.
export function PageHeader({ title, subtitle, right, icon, colorsOverride }) {
  const insets = useSafeAreaInsets();
  return (
    <LinearGradient colors={colorsOverride || gradients.brand} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[s.header, { paddingTop: insets.top + 14 }]}>
      <View style={s.headerBlobA} /><View style={s.headerBlobB} />
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <View style={{ flex: 1 }}>
          {icon ? <View style={s.kicker}><Ionicons name={icon} size={14} color="#fff" /><Text style={s.kickerText}>NutriMedi</Text></View> : null}
          <Text style={s.headerTitle} accessibilityRole="header">{title}</Text>
          {subtitle ? <Text style={s.headerSub}>{subtitle}</Text> : null}
        </View>
        {right}
      </View>
    </LinearGradient>
  );
}

// ---------------------------------------------------------------- buttons & inputs
export function Btn({ title, onPress, variant = 'warm', icon, loading, disabled, small, style, full = true }) {
  const off = disabled || loading;
  const inner = (
    <View style={[s.btnInner, small && { paddingVertical: 10, paddingHorizontal: 18 }]}>
      {loading ? <ActivityIndicator color={variant === 'light' || variant === 'outline' ? colors.navy : '#fff'} /> : (
        <>
          {icon ? <Ionicons name={icon} size={18} color={variant === 'light' || variant === 'outline' ? colors.navy : '#fff'} style={{ marginRight: 8 }} /> : null}
          <Text style={[s.btnText, (variant === 'light' || variant === 'outline') && { color: colors.navy }, small && { fontSize: 14 }]}>{title}</Text>
        </>
      )}
    </View>
  );
  const wrap = [s.btn, !full && { alignSelf: 'flex-start' }, off && { opacity: 0.55 }, style];
  if (variant === 'warm' || variant === 'brand' || variant === 'cool') {
    return (
      <Pressable accessibilityRole="button" accessibilityState={{ disabled: !!off }} disabled={off} onPress={onPress} style={({ pressed }) => [wrap, shadow.md, pressed && { transform: [{ scale: 0.98 }] }]}>
        <LinearGradient colors={gradients[variant]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={s.btnGrad}>{inner}</LinearGradient>
      </Pressable>
    );
  }
  const bg = { navy: { backgroundColor: colors.navy }, light: { backgroundColor: '#fff', ...shadow.sm }, outline: { backgroundColor: '#fff', borderWidth: 1.5, borderColor: colors.line }, danger: { backgroundColor: colors.danger }, whatsapp: { backgroundColor: '#1FAF55' } }[variant];
  return (
    <Pressable accessibilityRole="button" accessibilityState={{ disabled: !!off }} disabled={off} onPress={onPress} style={({ pressed }) => [wrap, bg, pressed && { transform: [{ scale: 0.98 }] }]}>
      {inner}
    </Pressable>
  );
}

export function Field({ label, error, hint, style, inputStyle, multiline, ...props }) {
  const [focus, setFocus] = useState(false);
  return (
    <View style={[{ marginBottom: 14 }, style]}>
      {label ? <Text style={s.label}>{label}</Text> : null}
      <TextInput
        placeholderTextColor="#9AA6C0"
        accessibilityLabel={label}
        multiline={multiline}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        style={[s.input, multiline && { minHeight: 96, textAlignVertical: 'top' }, focus && { borderColor: colors.purple }, !!error && { borderColor: colors.danger }, inputStyle]}
        {...props}
      />
      {error ? <Text style={s.error}>{error}</Text> : hint ? <Text style={s.hint}>{hint}</Text> : null}
    </View>
  );
}

export function Chip({ label, active, onPress, count, grad = gradients.brand }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" accessibilityState={{ selected: !!active }} style={{ marginRight: 10 }}>
      {active ? (
        <LinearGradient colors={grad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={s.chip}>
          <Text style={[s.chipText, { color: '#fff' }]}>{label}</Text>
          {count !== undefined ? <View style={[s.chipCount, { backgroundColor: 'rgba(255,255,255,.25)' }]}><Text style={[s.chipCountText, { color: '#fff' }]}>{count}</Text></View> : null}
        </LinearGradient>
      ) : (
        <View style={[s.chip, { backgroundColor: '#fff', borderWidth: 1.5, borderColor: colors.line }]}>
          <Text style={s.chipText}>{label}</Text>
          {count !== undefined ? <View style={s.chipCount}><Text style={s.chipCountText}>{count}</Text></View> : null}
        </View>
      )}
    </Pressable>
  );
}

export function SearchBar({ value, onChangeText, placeholder = 'Search…', style }) {
  return (
    <View style={[s.search, shadow.sm, style]}>
      <Ionicons name="search" size={20} color={colors.muted} />
      <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor="#9AA6C0" style={s.searchInput} accessibilityLabel={placeholder} returnKeyType="search" autoCorrect={false} />
      {value ? <Pressable onPress={() => onChangeText('')} hitSlop={10} accessibilityLabel="Clear search"><Ionicons name="close-circle" size={20} color={colors.muted} /></Pressable> : null}
    </View>
  );
}

// ---------------------------------------------------------------- content helpers
export function SectionHeader({ title, subtitle, action, onAction }) {
  return (
    <View style={s.sectionHead}>
      <View style={{ flex: 1 }}>
        <Text style={s.sectionTitle} accessibilityRole="header">{title}</Text>
        {subtitle ? <Text style={s.sectionSub}>{subtitle}</Text> : null}
      </View>
      {action ? <Pressable onPress={onAction} hitSlop={10}><Text style={s.sectionAction}>{action} →</Text></Pressable> : null}
    </View>
  );
}

export function Card({ children, style }) { return <View style={[s.card, shadow.md, style]}>{children}</View>; }

export function Empty({ icon = 'leaf-outline', title, message, action, onAction }) {
  return (
    <View style={s.empty}>
      <LinearGradient colors={gradients.cool} style={s.emptyIcon}><Ionicons name={icon} size={40} color="#fff" /></LinearGradient>
      <Text style={s.emptyTitle}>{title}</Text>
      {message ? <Text style={s.emptyMsg}>{message}</Text> : null}
      {action ? <Btn title={action} onPress={onAction} variant="navy" full={false} style={{ marginTop: 18 }} small /> : null}
    </View>
  );
}

export function ErrorBox({ message, onRetry }) {
  return <Empty icon="cloud-offline-outline" title="Something went wrong" message={message || 'Please check your connection and try again.'} action={onRetry ? 'Try again' : undefined} onAction={onRetry} />;
}

export function Notice({ type = 'info', children, style }) {
  const t = { info: [colors.softNavy, colors.navy, 'information-circle'], success: [colors.softSuccess, colors.success, 'checkmark-circle'], error: [colors.softDanger, colors.danger, 'alert-circle'], warn: [colors.softOrange, '#9A4A12', 'warning'] }[type];
  return (
    <View accessibilityLiveRegion="polite" style={[s.notice, { backgroundColor: t[0] }, style]}>
      <Ionicons name={t[2]} size={20} color={t[1]} style={{ marginRight: 10, marginTop: 1 }} />
      <Text style={{ flex: 1, color: t[1], fontSize: 14.5, lineHeight: 21, fontWeight: '600' }}>{children}</Text>
    </View>
  );
}

export function Skeleton({ height = 16, width = '100%', radiusPx = 10, style }) {
  const v = useRef(new Animated.Value(0.45)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([Animated.timing(v, { toValue: 1, duration: 700, useNativeDriver: true }), Animated.timing(v, { toValue: 0.45, duration: 700, useNativeDriver: true })]));
    loop.start();
    return () => loop.stop();
  }, [v]);
  return <Animated.View style={[{ height, width, borderRadius: radiusPx, backgroundColor: '#E6ECF6', opacity: v }, style]} />;
}

// Image with a gradient fallback when the URL is empty or fails to load.
export function RemoteImage({ uri, style, grad = gradients.cool, icon = 'leaf', resizeMode = 'cover' }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => { setFailed(false); }, [uri]);
  return (
    <View style={[{ overflow: 'hidden', backgroundColor: '#E6ECF6' }, style]}>
      <LinearGradient colors={grad} style={StyleSheet.absoluteFill} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} />
      {(!uri || failed) ? <View style={s.imgFallback}><Ionicons name={icon} size={46} color="rgba(255,255,255,.6)" /></View> : null}
      {uri && !failed ? <Image source={{ uri }} resizeMode={resizeMode} onError={() => setFailed(true)} style={StyleSheet.absoluteFill} accessibilityIgnoresInvertColors /> : null}
    </View>
  );
}

export function Row({ icon, title, subtitle, onPress, right, tint = colors.teal, soft = colors.softTeal }) {
  return (
    <Pressable onPress={onPress} disabled={!onPress} accessibilityRole={onPress ? 'button' : undefined} style={({ pressed }) => [s.rowItem, pressed && { backgroundColor: '#F1F5FB' }]}>
      <View style={[s.rowIcon, { backgroundColor: soft }]}><Ionicons name={icon} size={20} color={tint} /></View>
      <View style={{ flex: 1 }}>
        <Text style={s.rowTitle}>{title}</Text>
        {subtitle ? <Text style={s.rowSub}>{subtitle}</Text> : null}
      </View>
      {right !== undefined ? right : onPress ? <Ionicons name="chevron-forward" size={18} color={colors.muted} /> : null}
    </Pressable>
  );
}

// ---------------------------------------------------------------- toast
const ToastCtx = createContext({ show: () => {} });
export const useToast = () => useContext(ToastCtx);
export function ToastProvider({ children }) {
  const [msg, setMsg] = useState('');
  const a = useRef(new Animated.Value(0)).current;
  const timer = useRef(null);
  const insets = useSafeAreaInsets();
  const show = useCallback((m) => {
    setMsg(m);
    clearTimeout(timer.current);
    Animated.timing(a, { toValue: 1, duration: 180, useNativeDriver: true }).start();
    timer.current = setTimeout(() => Animated.timing(a, { toValue: 0, duration: 220, useNativeDriver: true }).start(), 2300);
  }, [a]);
  return (
    <ToastCtx.Provider value={{ show }}>
      {children}
      <Animated.View pointerEvents="none" accessibilityLiveRegion="polite" style={[s.toast, { bottom: insets.bottom + 92, opacity: a, transform: [{ translateY: a.interpolate({ inputRange: [0, 1], outputRange: [20, 0] }) }] }]}>
        <Text style={s.toastText}>{msg}</Text>
      </Animated.View>
    </ToastCtx.Provider>
  );
}

export const money = (n) => '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  header: { paddingHorizontal: 20, paddingBottom: 26, borderBottomLeftRadius: 30, borderBottomRightRadius: 30, overflow: 'hidden' },
  headerBlobA: { position: 'absolute', right: -50, top: -60, width: 190, height: 190, borderRadius: 95, backgroundColor: 'rgba(244,123,54,.45)' },
  headerBlobB: { position: 'absolute', left: -60, bottom: -80, width: 190, height: 190, borderRadius: 95, backgroundColor: 'rgba(118,87,214,.5)' },
  kicker: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', backgroundColor: 'rgba(255,255,255,.18)', paddingHorizontal: 12, paddingVertical: 5, borderRadius: 999, marginBottom: 10 },
  kickerText: { color: '#fff', fontWeight: '700', fontSize: 12, marginLeft: 6 },
  headerTitle: { color: '#fff', fontSize: 28, fontWeight: '800', letterSpacing: -0.6 },
  headerSub: { color: '#DBE7F5', fontSize: 14.5, lineHeight: 21, marginTop: 6 },
  btn: { borderRadius: radius.pill, overflow: 'hidden' },
  btnGrad: { borderRadius: radius.pill },
  btnInner: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 15, paddingHorizontal: 24, minHeight: 52 },
  btnText: { color: '#fff', fontWeight: '800', fontSize: 15.5 },
  label: { color: colors.navy, fontWeight: '700', fontSize: 14, marginBottom: 7 },
  input: { backgroundColor: '#fff', borderWidth: 1.5, borderColor: colors.line, borderRadius: radius.md, paddingHorizontal: 16, paddingVertical: 14, fontSize: 16, color: colors.navy, minHeight: 52 },
  error: { color: colors.danger, fontSize: 13, marginTop: 6, fontWeight: '600' },
  hint: { color: colors.muted, fontSize: 12.5, marginTop: 6 },
  chip: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 10, borderRadius: radius.pill, minHeight: 44 },
  chipText: { color: colors.navy, fontWeight: '700', fontSize: 14 },
  chipCount: { marginLeft: 8, backgroundColor: colors.softNavy, borderRadius: 999, paddingHorizontal: 8, paddingVertical: 1 },
  chipCountText: { color: colors.navy, fontWeight: '800', fontSize: 12 },
  search: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: radius.pill, paddingHorizontal: 18, minHeight: 54 },
  searchInput: { flex: 1, fontSize: 16, color: colors.navy, paddingVertical: 12, marginLeft: 10 },
  sectionHead: { flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 20, marginTop: 30, marginBottom: 14 },
  sectionTitle: { color: colors.navy, fontSize: 22, fontWeight: '800', letterSpacing: -0.4 },
  sectionSub: { color: colors.muted, fontSize: 13.5, marginTop: 3 },
  sectionAction: { color: colors.teal, fontWeight: '800', fontSize: 14 },
  card: { backgroundColor: '#fff', borderRadius: radius.lg, padding: 18 },
  empty: { alignItems: 'center', paddingVertical: 44, paddingHorizontal: 28 },
  emptyIcon: { width: 88, height: 88, borderRadius: 28, alignItems: 'center', justifyContent: 'center', transform: [{ rotate: '-6deg' }] },
  emptyTitle: { color: colors.navy, fontSize: 20, fontWeight: '800', marginTop: 20, textAlign: 'center' },
  emptyMsg: { color: colors.muted, fontSize: 14.5, lineHeight: 21, marginTop: 8, textAlign: 'center' },
  notice: { flexDirection: 'row', padding: 14, borderRadius: radius.md, marginBottom: 14 },
  imgFallback: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  rowItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 16 },
  rowIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginRight: 14 },
  rowTitle: { color: colors.navy, fontWeight: '700', fontSize: 15.5 },
  rowSub: { color: colors.muted, fontSize: 13, marginTop: 2 },
  toast: { position: 'absolute', alignSelf: 'center', backgroundColor: colors.navy, paddingHorizontal: 22, paddingVertical: 13, borderRadius: 999, maxWidth: '86%', ...shadow.lg },
  toastText: { color: '#fff', fontWeight: '700', fontSize: 14 }
});
