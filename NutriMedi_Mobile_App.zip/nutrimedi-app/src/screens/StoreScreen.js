import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { FlatList, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ProductCard } from '../components/ProductCard';
import { Chip, Empty, ErrorBox, PageHeader, SearchBar, Skeleton, useToast } from '../components/UI';
import { useData } from '../context/DataContext';
import { useCart } from '../context/CartContext';
import { catTheme } from '../utils/articleFormat';
import { colors, themes } from '../theme';

export default function StoreScreen({ navigation }) {
  const { products, loadProducts } = useData();
  const cart = useCart();
  const toast = useToast();
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  useEffect(() => { loadProducts(); }, [loadProducts]);

  const items = products.items;
  const cats = useMemo(() => [...new Set(items.map((p) => p.category))].sort(), [items]);
  const rows = useMemo(() => {
    const n = q.trim().toLowerCase();
    return items.filter((p) => (!cat || p.category === cat) && (!n || (p.name + ' ' + p.category + ' ' + p.description).toLowerCase().includes(n)));
  }, [items, q, cat]);
  const refresh = useCallback(async () => { setRefreshing(true); await loadProducts(true); setRefreshing(false); }, [loadProducts]);

  const header = (
    <View>
      <PageHeader icon="bag-handle" title="Wellness store" subtitle="Physical essentials and digital educational resources."
        right={(
          <Pressable onPress={() => navigation.navigate('Cart')} accessibilityRole="button" accessibilityLabel={`Cart, ${cart.count} items`} style={styles.cartBtn}>
            <Ionicons name="bag-handle" size={22} color="#fff" />
            {cart.count > 0 ? <View style={styles.dot}><Text style={styles.dotText}>{cart.count}</Text></View> : null}
          </Pressable>
        )} />
      <View style={{ paddingHorizontal: 16, marginTop: -22 }}><SearchBar value={q} onChangeText={setQ} placeholder="Search products…" /></View>
      {cats.length > 0 ? (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 16 }}>
          <Chip label="All products" active={!cat} onPress={() => setCat('')} />
          {cats.map((c) => <Chip key={c} label={c} active={cat === c} onPress={() => setCat(c)} grad={themes[catTheme(c)].grad} />)}
        </ScrollView>
      ) : <View style={{ height: 14 }} />}
    </View>
  );

  let empty = null;
  if (products.loading && !items.length) empty = <View style={styles.skels}>{[0, 1, 2, 3].map((i) => <Skeleton key={i} height={230} radiusPx={24} style={{ width: '47%' }} />)}</View>;
  else if (products.error && !items.length) empty = <ErrorBox message={products.error} onRetry={() => loadProducts(true)} />;
  else if (!items.length) empty = <Empty icon="bag-handle-outline" title="The store is being stocked" message="No products are available right now. Please check back soon." />;
  else if (!rows.length) empty = <Empty icon="search-outline" title="No matching products" message="Try another search or category." action="Clear filters" onAction={() => { setQ(''); setCat(''); }} />;

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <FlatList
        data={rows}
        numColumns={2}
        keyExtractor={(p) => p.id}
        ListHeaderComponent={header}
        ListEmptyComponent={empty}
        columnWrapperStyle={{ paddingHorizontal: 12, gap: 14 }}
        renderItem={({ item }) => (
          <View style={{ flex: 1, marginBottom: 14, maxWidth: '50%' }}>
            <ProductCard p={item} onPress={() => navigation.navigate('Product', { id: item.id })} onAdd={() => { cart.add(item); toast.show('Added to cart'); }} />
          </View>
        )}
        refreshing={refreshing}
        onRefresh={refresh}
        contentContainerStyle={{ paddingBottom: 120 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        initialNumToRender={6}
        windowSize={7}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  cartBtn: { width: 46, height: 46, borderRadius: 15, backgroundColor: 'rgba(255,255,255,.18)', alignItems: 'center', justifyContent: 'center' },
  dot: { position: 'absolute', right: -4, top: -4, minWidth: 20, height: 20, borderRadius: 10, backgroundColor: colors.orange, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5 },
  dotText: { color: '#fff', fontWeight: '800', fontSize: 11 },
  skels: { flexDirection: 'row', flexWrap: 'wrap', gap: 14, paddingHorizontal: 16 }
});
