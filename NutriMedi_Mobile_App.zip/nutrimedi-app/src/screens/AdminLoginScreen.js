import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Btn, Card, Field, Notice, PageHeader, Screen } from '../components/UI';
import { adminApi } from '../api';
import { colors } from '../theme';

// Uses the existing /api/admin-login (email + PIN). The backend sets a 30-minute session cookie;
// we confirm it with /api/admin-session before opening the dashboard. No credentials are stored on the device.
export default function AdminLoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');

  const login = async () => {
    if (!email.trim() || !password) { setMsg('Enter the admin email and password / PIN.'); return; }
    setBusy(true); setMsg('');
    try {
      await adminApi.login(email.trim(), password);
      const ok = await adminApi.session();
      if (!ok) throw new Error('Signed in, but the session could not be kept on this device. Please try again.');
      setPassword('');
      navigation.replace('AdminHome');
    } catch (e) { setMsg(e.message); }
    finally { setBusy(false); }
  };

  return (
    <Screen keyboard header={<PageHeader icon="shield-checkmark" title="Admin sign in" subtitle="Authorised NutriMedi staff only." colorsOverride={['#142B59', '#7657D6']} right={<Pressable onPress={() => navigation.goBack()} accessibilityRole="button" accessibilityLabel="Close" style={{ width: 46, height: 46, borderRadius: 15, backgroundColor: 'rgba(255,255,255,.18)', alignItems: 'center', justifyContent: 'center' }}><Ionicons name="close" size={24} color="#fff" /></Pressable>} />}>
      <View style={{ padding: 16 }}>
        <Card>
          {msg ? <Notice type="error">{msg}</Notice> : null}
          <Field label="Admin email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoCorrect={false} textContentType="username" />
          <Field label="Admin password / PIN" value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" autoCorrect={false} textContentType="password" onSubmitEditing={login} />
          <Btn title="Sign in" icon="log-in" onPress={login} loading={busy} variant="navy" />
          <Text style={{ color: colors.muted, fontSize: 12.5, marginTop: 14, lineHeight: 18 }}>Sessions last 30 minutes, the same as the website admin panel.</Text>
        </Card>
      </View>
    </Screen>
  );
}
