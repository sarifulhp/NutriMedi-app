import React, { useEffect, useRef, useState } from 'react';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import * as WebBrowser from 'expo-web-browser';
import { Ionicons } from '@expo/vector-icons';
import { Card, PageHeader, Row, Screen } from '../components/UI';
import { adminApi } from '../api';
import { CONTACT, POLICIES, SITE_URL } from '../config';
import { colors } from '../theme';

export default function MoreScreen({ navigation }) {
  const [showAdmin, setShowAdmin] = useState(false);
  const taps = useRef(0);
  const timer = useRef(null);

  // The admin entry is not shown to ordinary users. It appears if a valid admin session already exists,
  // or after tapping the version label five times. Real protection is the backend login either way.
  useEffect(() => { adminApi.session().then((ok) => { if (ok) setShowAdmin(true); }).catch(() => {}); }, []);
  const tapVersion = () => {
    taps.current += 1; clearTimeout(timer.current);
    timer.current = setTimeout(() => { taps.current = 0; }, 2500);
    if (taps.current >= 5) { taps.current = 0; setShowAdmin(true); }
  };
  const web = (path) => WebBrowser.openBrowserAsync(SITE_URL + path, { toolbarColor: '#142B59', controlsColor: '#fff' });

  return (
    <Screen header={<PageHeader icon="menu" title="Menu" subtitle="About NutriMedi, contact details and policies." right={<Pressable onPress={() => navigation.goBack()} accessibilityRole="button" accessibilityLabel="Close menu" style={styles.close}><Ionicons name="close" size={24} color="#fff" /></Pressable>} />} bottomPad={60}>
      <View style={{ padding: 16, gap: 16 }}>
        <Card>
          <Text style={styles.h}>About NutriMedi</Text>
          <Text style={styles.p}>Professional, convenient nutrition consultations and thoughtfully selected wellness essentials.</Text>
          <Text style={[styles.p, { fontWeight: '800', color: colors.teal, marginTop: 8 }]}>Better Nutrition. Healthier Living.</Text>
          <Row icon="globe-outline" title="Visit nutrimedi.in" onPress={() => Linking.openURL(SITE_URL)} />
        </Card>

        <Card style={{ padding: 4 }}>
          <Text style={[styles.h, { padding: 14, paddingBottom: 4 }]}>Contact</Text>
          <Row icon="mail-outline" title="Email" subtitle={CONTACT.email} onPress={() => Linking.openURL('mailto:' + CONTACT.email)} />
          <Row icon="call-outline" title="Call" subtitle={CONTACT.phoneLabel} onPress={() => Linking.openURL('tel:' + CONTACT.phone)} tint={colors.purple} soft={colors.softPurple} />
          <Row icon="logo-whatsapp" title="WhatsApp" subtitle="Chat with us" onPress={() => Linking.openURL(CONTACT.whatsapp)} tint="#1FAF55" soft="#E1F6E8" />
          <Row icon="location-outline" title="Address" subtitle={CONTACT.address} onPress={() => Linking.openURL('https://maps.google.com/?q=' + encodeURIComponent(CONTACT.address))} tint={colors.orange} soft={colors.softOrange} />
        </Card>

        <Card style={{ padding: 4 }}>
          <Text style={[styles.h, { padding: 14, paddingBottom: 4 }]}>Policies</Text>
          {POLICIES.map((p) => <Row key={p.path} icon="document-text-outline" title={p.title} onPress={() => web(p.path)} tint={colors.navy} soft={colors.softNavy} />)}
        </Card>

        {showAdmin ? (
          <Card style={{ padding: 4 }}>
            <Row icon="shield-checkmark-outline" title="Admin" subtitle="Authorised staff only" onPress={() => navigation.navigate('AdminLogin')} tint={colors.pink} soft={colors.softPink} />
          </Card>
        ) : null}

        <Pressable onPress={tapVersion} accessibilityRole="text" style={{ alignItems: 'center', padding: 10 }}>
          <Text style={styles.ver}>NutriMedi app 1.0.0</Text>
          <Text style={styles.fine}>Nutrition and wellness information is not a substitute for licensed medical diagnosis or emergency care.</Text>
        </Pressable>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  close: { width: 46, height: 46, borderRadius: 15, backgroundColor: 'rgba(255,255,255,.18)', alignItems: 'center', justifyContent: 'center' },
  h: { color: colors.navy, fontSize: 18, fontWeight: '800', marginBottom: 6 },
  p: { color: colors.text, fontSize: 15, lineHeight: 22 },
  ver: { color: colors.muted, fontWeight: '700', fontSize: 13 },
  fine: { color: colors.muted, fontSize: 12, lineHeight: 17, textAlign: 'center', marginTop: 6 }
});
