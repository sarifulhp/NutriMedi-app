import React, { useEffect, useRef } from 'react';
import { Animated, Linking, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { RemoteImage } from './UI';
import { colors, radius, shadow, themeNames, themes } from '../theme';
import { toSegments } from '../utils/articleFormat';

// Renders the sanitised inline markup (bold / italic / links) as nested <Text>.
export function Rich({ html, style, linkColor = colors.teal }) {
  const segs = toSegments(html);
  return (
    <Text style={style} selectable>
      {segs.map((g, i) => (
        <Text
          key={i}
          style={[g.bold && { fontWeight: '800' }, g.italic && { fontStyle: 'italic' }, g.href && { color: linkColor, textDecorationLine: 'underline' }]}
          onPress={g.href ? () => Linking.openURL(g.href).catch(() => {}) : undefined}
        >{g.text}</Text>
      ))}
    </Text>
  );
}

const CALLOUT = {
  fact: { grad: ['#F47B36', '#E94F91'], icon: 'bulb' },
  tip: { grad: ['#087F78', '#0AA39A'], icon: 'leaf' },
  warn: { grad: ['#7657D6', '#9A6BFF'], icon: 'alert-circle' }
};

// Visual style for the section at position i (alternating soft and solid cards, like the website reader).
export function sectionStyle(i, hasTitle) {
  if (!hasTitle) return { kind: 'intro', bg: '#fff', ink: colors.navy, txt: colors.text, inner: '#fff', innerInk: colors.navy, th: themes.orange, solid: false };
  const th = themes[themeNames[i % themeNames.length]];
  if (i % 4 === 1) return { kind: 'solid', grad: ['#142B59', '#087F78'], ink: '#fff', txt: '#EAF0FB', inner: 'rgba(255,255,255,.16)', innerInk: '#fff', th, solid: true };
  if (i % 4 === 3) return { kind: 'solid', grad: ['#7657D6', '#142B59'], ink: '#fff', txt: '#EAF0FB', inner: 'rgba(255,255,255,.16)', innerInk: '#fff', th, solid: true };
  return { kind: 'soft', bg: th.soft, ink: colors.navy, txt: colors.text, inner: '#fff', innerInk: colors.navy, th, solid: false };
}

function Block({ b, st, bn }) {
  const body = [styles.p, { color: st.txt }, bn && styles.pBn];
  switch (b.t) {
    case 'p':
      return <Rich html={b.html} style={body} linkColor={st.solid ? '#FFD9BD' : st.th.a} />;
    case 'h':
      return <Text style={[styles.sub, { color: st.solid ? '#FFD9BD' : st.th.a }]}>{b.html.replace(/<[^>]+>/g, '')}</Text>;
    case 'ol':
      return (
        <View style={{ gap: 10 }}>
          {b.items.map((it, n) => (
            <View key={n} style={[styles.tip, { backgroundColor: st.inner }]}>
              <View style={[styles.tipNum, { backgroundColor: st.solid ? '#fff' : st.th.a }]}><Text style={[styles.tipNumText, { color: st.solid ? colors.navy : '#fff' }]}>{n + 1}</Text></View>
              <Rich html={it} style={[styles.tipText, { color: st.innerInk }, bn && styles.pBn]} linkColor={st.th.a} />
            </View>
          ))}
        </View>
      );
    case 'ul':
      return (
        <View style={{ gap: 10 }}>
          {b.items.map((it, n) => (
            <View key={n} style={[styles.tip, { backgroundColor: st.inner }]}>
              <View style={[styles.tick, { backgroundColor: st.solid ? '#fff' : st.th.a }]}><Ionicons name="checkmark" size={16} color={st.solid ? colors.teal : '#fff'} /></View>
              <Rich html={it} style={[styles.tipText, { color: st.innerInk }, bn && styles.pBn]} linkColor={st.th.a} />
            </View>
          ))}
        </View>
      );
    case 'quote':
      return (
        <View style={[styles.quote, { backgroundColor: st.inner }]}>
          <Text style={[styles.quoteMark, { color: st.solid ? '#fff' : st.th.a }]}>“</Text>
          <Rich html={b.html} style={[styles.quoteText, { color: st.innerInk }, bn && styles.pBn]} linkColor={st.th.a} />
        </View>
      );
    case 'callout': {
      const c = CALLOUT[b.kind];
      return (
        <LinearGradient colors={c.grad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.callout}>
          <View style={styles.calloutLabel}><Ionicons name={c.icon} size={14} color="#fff" /><Text style={styles.calloutLabelText}>{b.label}</Text></View>
          <Rich html={b.html} style={[styles.calloutText, bn && styles.pBn]} linkColor="#fff" />
        </LinearGradient>
      );
    }
    case 'compare':
      return (
        <View style={{ gap: 12 }}>
          {[['before', colors.orange], ['after', colors.teal]].map(([k, c]) => (
            <View key={k} style={[styles.cmp, { borderTopColor: c }]}>
              <View style={[styles.cmpLabel, { backgroundColor: c }]}><Text style={styles.cmpLabelText}>{b[k].label}</Text></View>
              <Rich html={b[k].body} style={[styles.tipText, { color: colors.navy }, bn && styles.pBn]} linkColor={c} />
            </View>
          ))}
        </View>
      );
    case 'img':
      return (
        <View style={[styles.imgWrap, shadow.md]}>
          <RemoteImage uri={b.src} grad={st.th.grad} style={{ width: '100%', aspectRatio: 4 / 3 }} />
          {b.cap ? <Text style={styles.cap}>{b.cap}</Text> : null}
        </View>
      );
    case 'table':
      return (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={[styles.table, { backgroundColor: st.inner }]}>
          <View>
            {b.rows.map((r, ri) => (
              <View key={ri} style={{ flexDirection: 'row' }}>
                {r.map((c, ci) => (
                  <View key={ci} style={[styles.cell, c.head && { backgroundColor: st.th.a }]}>
                    <Text style={{ color: c.head ? '#fff' : st.innerInk, fontWeight: c.head ? '800' : '500', fontSize: 14 }}>{c.html.replace(/<[^>]+>/g, '')}</Text>
                  </View>
                ))}
              </View>
            ))}
          </View>
        </ScrollView>
      );
    default:
      return null;
  }
}

// One article section. `revealed` fades it in once it scrolls into view; a timer guarantees it is never left hidden.
export function SectionCard({ section, index, number, revealed, bn }) {
  const st = sectionStyle(index, !!section.plainTitle);
  const v = useRef(new Animated.Value(0)).current;
  const shown = useRef(false);
  const go = () => {
    if (shown.current) return;
    shown.current = true;
    Animated.timing(v, { toValue: 1, duration: 520, useNativeDriver: true }).start();
  };
  useEffect(() => { if (revealed) go(); }, [revealed]);
  useEffect(() => { const t = setTimeout(go, 1200); return () => clearTimeout(t); }, []);

  const content = (
    <View style={{ padding: 22 }}>
      {section.plainTitle ? (
        <View style={styles.head}>
          <View style={[styles.num, { backgroundColor: st.solid ? '#fff' : st.th.a }]}>
            <Text style={[styles.numText, { color: st.solid ? colors.navy : '#fff' }]}>{String(number).padStart(2, '0')}</Text>
          </View>
          <Text style={[styles.title, { color: st.ink }, bn && { lineHeight: 36 }]} accessibilityRole="header">{section.plainTitle}</Text>
        </View>
      ) : null}
      <View style={{ gap: 14 }}>
        {section.blocks.map((b, i) => <Block key={i} b={b} st={st} bn={bn} />)}
      </View>
    </View>
  );

  return (
    <Animated.View style={[styles.card, shadow.md, { opacity: v, transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [28, 0] }) }] }]}>
      {st.solid
        ? <LinearGradient colors={st.grad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>{content}</LinearGradient>
        : <View style={{ backgroundColor: st.bg }}><View style={[styles.bar, { backgroundColor: st.kind === 'intro' ? colors.orange : st.th.a }]} />{content}</View>}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  card: { marginHorizontal: 14, marginBottom: 18, borderRadius: radius.xl, overflow: 'hidden', backgroundColor: '#fff' },
  bar: { position: 'absolute', left: 0, top: 0, bottom: 0, width: 6 },
  head: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 16 },
  num: { width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginRight: 14 },
  numText: { fontWeight: '800', fontSize: 17 },
  title: { flex: 1, fontSize: 25, fontWeight: '800', lineHeight: 31, letterSpacing: -0.4, paddingTop: 2 },
  p: { fontSize: 17, lineHeight: 28 },
  pBn: { fontSize: 18, lineHeight: 32 },
  sub: { fontSize: 20, fontWeight: '800', marginTop: 8, letterSpacing: -0.2 },
  tip: { flexDirection: 'row', alignItems: 'flex-start', borderRadius: 18, padding: 14 },
  tipNum: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  tipNumText: { fontWeight: '800', fontSize: 15 },
  tick: { width: 26, height: 26, borderRadius: 13, alignItems: 'center', justifyContent: 'center', marginRight: 12, marginTop: 2 },
  tipText: { flex: 1, fontSize: 16, lineHeight: 25, paddingTop: 3 },
  quote: { borderRadius: 20, padding: 20, paddingTop: 34 },
  quoteMark: { position: 'absolute', left: 14, top: -2, fontSize: 60, lineHeight: 66, opacity: 0.35 },
  quoteText: { fontSize: 18, lineHeight: 28, fontWeight: '700' },
  callout: { borderRadius: 20, padding: 18 },
  calloutLabel: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', backgroundColor: 'rgba(255,255,255,.28)', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 5, marginBottom: 10 },
  calloutLabelText: { color: '#fff', fontWeight: '800', fontSize: 12.5, marginLeft: 6 },
  calloutText: { color: '#fff', fontSize: 16.5, lineHeight: 26, fontWeight: '600' },
  cmp: { backgroundColor: '#fff', borderRadius: 18, borderTopWidth: 5, padding: 16 },
  cmpLabel: { alignSelf: 'flex-start', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 4, marginBottom: 8 },
  cmpLabelText: { color: '#fff', fontWeight: '800', fontSize: 12.5 },
  imgWrap: { borderRadius: 22, overflow: 'hidden', backgroundColor: '#fff' },
  cap: { padding: 12, fontSize: 13.5, color: colors.muted, backgroundColor: '#fff' },
  table: { borderRadius: 16 },
  cell: { minWidth: 120, paddingHorizontal: 14, paddingVertical: 11, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: 'rgba(20,43,89,.15)' }
});
