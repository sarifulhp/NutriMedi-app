import React, { useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider, useAuth } from './src/context/AuthContext';
import { CartProvider, useCart } from './src/context/CartContext';
import { BookmarksProvider } from './src/context/BookmarksContext';
import { DataProvider } from './src/context/DataContext';
import { ToastProvider } from './src/components/UI';
import Navigation from './src/navigation';

SplashScreen.preventAutoHideAsync().catch(() => {});

// Hides the splash screen once the saved session and cart have been read from the device.
function Gate({ children }) {
  const auth = useAuth();
  const cart = useCart();
  const ready = auth.ready && cart.ready;
  useEffect(() => { if (ready) SplashScreen.hideAsync().catch(() => {}); }, [ready]);
  return ready ? children : null;
}

export default function App() {
  return (
    <SafeAreaProvider>
      <AuthProvider>
        <CartProvider>
          <BookmarksProvider>
            <DataProvider>
              <ToastProvider>
                <StatusBar style="dark" />
                <Gate><Navigation /></Gate>
              </ToastProvider>
            </DataProvider>
          </BookmarksProvider>
        </CartProvider>
      </AuthProvider>
    </SafeAreaProvider>
  );
}
