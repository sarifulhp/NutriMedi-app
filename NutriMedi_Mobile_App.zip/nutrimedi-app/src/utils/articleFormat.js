// DOM-free article formatter (React Native has no DOM).
// Converts the stored article HTML / raw text into clean blocks:
//   - drops unsafe markup, empty paragraphs, &nbsp;, repeated breaks
//   - removes raw Markdown symbols (###, **, __, `, >, ---) and turns them into real structure
//   - never rewrites or invents wording
import { themeNames } from '../theme';

// ---------------------------------------------------------------- helpers
export function isBengali(t) { return /[\u0980-\u09FF]/.test(String(t || '')); }

export function catTheme(cat) {
  const s = String(cat || 'x');
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return themeNames[h % themeNames.length];
}

export function formatDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return d.getDate() + ' ' + m[d.getMonth()] + ' ' + d.getFullYear();
}

export function initials(name) {
  const p = String(name || 'N').trim().split(/\s+/).slice(0, 2);
  return p.map((x) => x.charAt(0)).join('').toUpperCase() || 'N';
}

export function safeUrl(u) {
  u = String(u || '').trim();
  return /^https?:\/\//i.test(u) ? u : '';
}

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', ndash: '–', mdash: '—', hellip: '…', rsquo: '’', lsquo: '‘', rdquo: '”', ldquo: '“' };
function decode(s) {
  return String(s).replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
    if (e[0] === '#') {
      const c = e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(c) ? String.fromCodePoint(c) : m;
    }
    const v = ENT[e.toLowerCase()];
    return v === undefined ? m : v;
  });
}
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function plain(html) { return decode(String(html).replace(/<[^>]*>/g, '')).replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim(); }

// ---------------------------------------------------------------- tiny HTML parser
const VOID = { br: 1, img: 1, hr: 1, meta: 1, link: 1, input: 1, source: 1, wbr: 1 };
function parseHtml(src) {
  const root = { type: 'el', tag: 'root', attrs: {}, children: [] };
  const stack = [root];
  const re = /<!--[\s\S]*?-->|<\/?([a-zA-Z][a-zA-Z0-9-]*)((?:"[^"]*"|'[^']*'|[^'">])*)>|[^<]+|</g;
  let m;
  while ((m = re.exec(src))) {
    const tok = m[0];
    const top = stack[stack.length - 1];
    if (tok.startsWith('<!--')) continue;
    if (m[1]) {
      const tag = m[1].toLowerCase();
      if (tok[1] === '/') {
        for (let i = stack.length - 1; i > 0; i--) { if (stack[i].tag === tag) { stack.length = i; break; } }
        continue;
      }
      const attrs = {};
      String(m[2] || '').replace(/([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*(?:=\s*("([^"]*)"|'([^']*)'|([^\s"'>]+)))?/g, (x, k, v, a, b, c) => {
        attrs[k.toLowerCase()] = decode(a ?? b ?? c ?? '');
        return x;
      });
      const el = { type: 'el', tag, attrs, children: [] };
      top.children.push(el);
      if (!VOID[tag] && !/\/\s*$/.test(m[2] || '')) stack.push(el);
    } else {
      top.children.push({ type: 'text', value: tok });
    }
  }
  return root;
}
function hasTag(node, tag) {
  if (node.type !== 'el') return false;
  if (node.tag === tag) return true;
  return node.children.some((c) => hasTag(c, tag));
}
function findTag(node, tag) {
  if (node.type !== 'el') return null;
  if (node.tag === tag) return node;
  for (const c of node.children) { const r = findTag(c, tag); if (r) return r; }
  return null;
}

// ---------------------------------------------------------------- sanitising to a mini inline markup
const DROP = new Set(['script', 'style', 'iframe', 'object', 'embed', 'form', 'input', 'button', 'textarea', 'select', 'noscript', 'svg', 'link', 'meta', 'head', 'title']);
const CONTAINER = new Set(['div', 'section', 'article', 'main', 'header', 'footer', 'aside', 'center', 'body', 'html', 'root']);
const INLINE = new Set(['strong', 'b', 'em', 'i', 'u', 'mark', 'sup', 'sub', 'del', 's', 'small']);

function cleanInline(node) {
  let out = '';
  for (const n of node.children) {
    if (n.type === 'text') { out += esc(decode(n.value).replace(/\u00a0/g, ' ')); continue; }
    const t = n.tag;
    if (DROP.has(t)) continue;
    if (t === 'br') { out += '<br>'; continue; }
    if (t === 'a') {
      const href = String(n.attrs.href || '').trim();
      const inner = cleanInline(n);
      out += /^(https?:|mailto:|tel:)/i.test(href) ? '<a href="' + esc(href) + '">' + inner + '</a>' : inner;
      continue;
    }
    if (INLINE.has(t)) { out += '<' + t + '>' + cleanInline(n) + '</' + t + '>'; continue; }
    out += cleanInline(n);
  }
  return out;
}

function inlineMd(s) {
  return s
    .replace(/\\([*_#`>~-])/g, '$1')
    .replace(/\*\*\*([^*\n]+?)\*\*\*/g, '<strong><em>$1</em></strong>')
    .replace(/\*\*([^*\n]+?)\*\*/g, '<strong>$1</strong>')
    .replace(/__([^_\n]+?)__/g, '<strong>$1</strong>')
    .replace(/(^|[\s(>])\*(?!\s)([^*\n]+?)\*(?=[\s).,;:!?<]|$)/g, '$1<em>$2</em>')
    .replace(/`([^`\n]+)`/g, '$1')
    .replace(/\*\*|__/g, '')
    .replace(/(^|\s)#{1,6}(?=\s|$)/g, '$1');
}

// ---------------------------------------------------------------- text -> blocks
function pushText(html, out) {
  const lines = String(html).split(/<br\s*\/?>|\r?\n/i);
  for (const raw of lines) {
    const line = raw.replace(/\u00a0|&nbsp;/g, ' ').trim();
    const txt = plain(line);
    if (!txt) continue;
    let m;
    if (/^([-*_=~])\1{2,}$/.test(txt.replace(/\s/g, ''))) continue; // horizontal rule

    if ((m = txt.match(/^(#{1,6})\s*(.+?)\s*#*$/))) {
      const inner = line.replace(/^\s*#{1,6}\s*/, '').replace(/\s*#+\s*$/, '');
      out.push({ t: 'h', level: Math.max(2, m[1].length), html: inlineMd(inner) });
      continue;
    }
    if ((m = txt.match(/^([-*•●▪◦]|\d{1,2}[.)]|[\u09E6-\u09EF]{1,2}[.)])\s+(.+)$/))) {
      const ordered = /^(\d|[\u09E6-\u09EF])/.test(m[1]);
      const li = inlineMd(line.replace(/^\s*(?:[-*•●▪◦]|\d{1,2}[.)]|[\u09E6-\u09EF]{1,2}[.)])\s+/, ''));
      const last = out[out.length - 1];
      const type = ordered ? 'ol' : 'ul';
      if (last && last.t === type && last.open) last.items.push(li);
      else out.push({ t: type, items: [li], open: true });
      continue;
    }
    if (/^(&gt;|>)\s?/.test(line)) {
      const q = inlineMd(line.replace(/^(&gt;|>)\s?/, ''));
      const lq = out[out.length - 1];
      if (lq && lq.t === 'quote' && lq.open) lq.html += ' ' + q; else out.push({ t: 'quote', html: q, open: true });
      continue;
    }
    if (/^<(strong|b)>[^<]{2,90}<\/(strong|b)>:?$/i.test(line) && !/[.!?।]$/.test(txt)) {
      out.push({ t: 'h', level: 3, html: inlineMd(txt.replace(/:$/, '')) });
      continue;
    }
    out.push({ t: 'p', html: inlineMd(line) });
  }
}

function collectItems(list, items) {
  for (const li of list.children) {
    if (li.type !== 'el' || li.tag !== 'li') continue;
    const own = { type: 'el', tag: 'li', attrs: {}, children: li.children.filter((c) => !(c.type === 'el' && (c.tag === 'ul' || c.tag === 'ol'))) };
    const h = inlineMd(cleanInline(own).replace(/<br>/g, ' ').trim());
    if (plain(h)) items.push(h);
    li.children.forEach((c) => { if (c.type === 'el' && (c.tag === 'ul' || c.tag === 'ol')) collectItems(c, items); });
  }
}

function walk(parent, out) {
  let buf = '';
  const flush = () => { if (buf) { pushText(buf, out); buf = ''; } };
  for (const n of parent.children) {
    if (n.type === 'text') { buf += esc(decode(n.value)); continue; }
    const t = n.tag;
    if (DROP.has(t)) continue;
    if (t === 'br') { buf += '<br>'; continue; }
    if (CONTAINER.has(t)) { flush(); walk(n, out); continue; }
    if (/^h[1-6]$/.test(t)) {
      flush();
      const h = inlineMd(cleanInline(n).replace(/<br>/g, ' ').replace(/^\s*#{1,6}\s*/, '').trim());
      if (plain(h)) out.push({ t: 'h', level: Math.max(2, +t.charAt(1)), html: h });
      continue;
    }
    if (t === 'p') {
      flush();
      if (hasTag(n, 'img')) { walk(n, out); continue; }
      pushText(cleanInline(n), out);
      continue;
    }
    if (t === 'ul' || t === 'ol') {
      flush();
      const items = [];
      collectItems(n, items);
      if (items.length) out.push({ t, items });
      continue;
    }
    if (t === 'blockquote') {
      flush();
      const qh = inlineMd(cleanInline(n).replace(/<br>/g, ' ').trim());
      if (plain(qh)) out.push({ t: 'quote', html: qh });
      continue;
    }
    if (t === 'img' || t === 'figure' || t === 'picture') {
      flush();
      const img = t === 'img' ? n : findTag(n, 'img');
      const src = img ? safeUrl(img.attrs.src) : '';
      if (src) {
        const fc = t === 'figure' ? findTag(n, 'figcaption') : null;
        out.push({ t: 'img', src, alt: String(img.attrs.alt || '').trim(), cap: fc ? plain(cleanInline(fc)) : '' });
      }
      continue;
    }
    if (t === 'table') {
      flush();
      const rows = [];
      const trs = [];
      (function find(x) { if (x.type !== 'el') return; if (x.tag === 'tr') trs.push(x); else x.children.forEach(find); })(n);
      trs.forEach((tr) => {
        const cells = tr.children.filter((c) => c.type === 'el' && (c.tag === 'td' || c.tag === 'th'))
          .map((c) => ({ head: c.tag === 'th', html: inlineMd(cleanInline(c)) }));
        if (cells.length) rows.push(cells);
      });
      if (rows.length) out.push({ t: 'table', rows });
      continue;
    }
    if (t === 'hr') { flush(); continue; }
    if (INLINE.has(t)) { buf += '<' + t + '>' + cleanInline(n) + '</' + t + '>'; continue; }
    buf += cleanInline(n);
  }
  flush();
}

export function parseBlocks(html) {
  const out = [];
  walk(parseHtml(String(html || '')), out);
  out.forEach((b) => { delete b.open; });
  return out;
}

// ---------------------------------------------------------------- inline markup -> segments for <Text>
export function toSegments(html) {
  const segs = [];
  const st = { b: 0, i: 0, u: 0, href: null };
  const hrefStack = [];
  const re = /<(\/?)(strong|b|em|i|u|a|mark|sup|sub|del|s|small|br)((?:\s[^>]*)?)>|([^<]+)/gi;
  let m;
  while ((m = re.exec(html))) {
    if (m[4] !== undefined) {
      const text = decode(m[4]);
      if (text) segs.push({ text, bold: st.b > 0, italic: st.i > 0, underline: st.u > 0, href: st.href });
      continue;
    }
    const close = m[1] === '/', tag = m[2].toLowerCase();
    if (tag === 'br') { segs.push({ text: '\n' }); continue; }
    const d = close ? -1 : 1;
    if (tag === 'strong' || tag === 'b') st.b = Math.max(0, st.b + d);
    else if (tag === 'em' || tag === 'i') st.i = Math.max(0, st.i + d);
    else if (tag === 'u') st.u = Math.max(0, st.u + d);
    else if (tag === 'a') {
      if (close) { hrefStack.pop(); st.href = hrefStack[hrefStack.length - 1] || null; }
      else { const h = /href="([^"]*)"/.exec(m[3] || ''); hrefStack.push(h ? decode(h[1]) : null); st.href = hrefStack[hrefStack.length - 1]; st.u++; }
      if (close) st.u = Math.max(0, st.u - 1);
    }
  }
  return segs;
}

// ---------------------------------------------------------------- callouts (labels come from the author's own text)
const SEP = '\\s*([:\\uFF1A\\-\\u2013\\u2014?])\\s*';
const SEP_NOQ = '\\s*([:\\uFF1A\\-\\u2013\\u2014])\\s*';
const RE_FACT = new RegExp('^(did you know|fun fact|fact|জানেন কি|মজার তথ্য|জেনে রাখুন|তথ্য)' + SEP, 'i');
const RE_TIP = new RegExp('^(nutrition tip|pro tip|quick tip|tips?|টিপস?|পরামর্শ)' + SEP_NOQ, 'i');
const RE_WARN = new RegExp('^(important|warning|caution|note|সতর্কতা|গুরুত্বপূর্ণ|মনে রাখবেন)' + SEP_NOQ, 'i');
const RE_BEFORE = new RegExp('^(before|আগে)' + SEP_NOQ, 'i');
const RE_AFTER = new RegExp('^(after|পরে)' + SEP_NOQ, 'i');

function leadText(html, re) {
  const m = plain(html).match(re);
  if (!m) return null;
  const label = m[1] + (m[2] === '?' ? '?' : '');
  const cut = html.replace(/^\s*(<(strong|b|em|i)>)?\s*[^<:\uFF1A\-\u2013\u2014?]{1,30}[:\uFF1A\-\u2013\u2014?]\s*(<\/(strong|b|em|i)>)?\s*/i, '');
  return { label, body: cut || html };
}

// Turns raw blocks into render-ready blocks (callouts, comparisons, numbered tips…)
function refine(blocks) {
  const out = [];
  for (let i = 0; i < blocks.length; i++) {
    const b = blocks[i];
    if (b.t === 'p') {
      const nxt = blocks[i + 1];
      const t = plain(b.html);
      if (RE_BEFORE.test(t) && nxt && nxt.t === 'p' && RE_AFTER.test(plain(nxt.html))) {
        const bf = leadText(b.html, RE_BEFORE), af = leadText(nxt.html, RE_AFTER);
        out.push({ t: 'compare', before: bf, after: af });
        i++; continue;
      }
      let r;
      if (RE_FACT.test(t) && (r = leadText(b.html, RE_FACT))) out.push({ t: 'callout', kind: 'fact', label: r.label, html: r.body });
      else if (RE_TIP.test(t) && (r = leadText(b.html, RE_TIP))) out.push({ t: 'callout', kind: 'tip', label: r.label, html: r.body });
      else if (RE_WARN.test(t) && (r = leadText(b.html, RE_WARN))) out.push({ t: 'callout', kind: 'warn', label: r.label, html: r.body });
      else out.push(b);
    } else out.push(b);
  }
  return out;
}

// Split into sections at the shallowest heading level present.
export function buildSections(contentHtml) {
  const blocks = parseBlocks(contentHtml);
  const levels = blocks.filter((b) => b.t === 'h').map((b) => b.level);
  const split = levels.length ? Math.min(...levels) : 0;
  const sections = [];
  let cur = { title: '', blocks: [] };
  blocks.forEach((b) => {
    if (b.t === 'h' && b.level === split) {
      if (cur.title || cur.blocks.length) sections.push(cur);
      cur = { title: b.html, blocks: [] };
    } else cur.blocks.push(b);
  });
  if (cur.title || cur.blocks.length) sections.push(cur);
  return sections.map((s, i) => ({ id: 's' + i, title: s.title, plainTitle: plain(s.title), blocks: refine(s.blocks) }));
}

export function readMins(html) {
  const t = plain(String(html || '').replace(/[#*_`>]/g, ' '));
  if (!t) return 1;
  return Math.max(1, Math.round(t.split(/\s+/).length / 190));
}

// Normalises an article returned by /api/articles for the app's UI.
export function readyArticle(a) {
  return {
    id: String(a.id || a.slug || ''),
    slug: String(a.slug || ''),
    title: String(a.title || 'Untitled'),
    category: String(a.category || '').trim(),
    excerpt: String(a.excerpt || '').trim(),
    cover: safeUrl(a.coverImage),
    author: String(a.author || '').trim() || 'NutriMedi',
    time: a.publishedAt || a.updatedAt || '',
    contentHtml: a.contentHtml || '',
    seoTitle: a.seoTitle || '',
    keywords: a.keywords || '',
    status: a.status || '',
    mins: readMins(a.contentHtml),
    theme: catTheme(a.category),
    bn: isBengali(String(a.title || '') + ' ' + String(a.excerpt || ''))
  };
}
export { plain };
