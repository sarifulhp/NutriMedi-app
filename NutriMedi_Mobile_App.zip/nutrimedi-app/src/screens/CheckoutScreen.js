import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import DownloadButton from '../components/DownloadButton';
import { Btn, Card, Field, Notice, Screen, money } from '../components/UI';
import { storeApi } from '../api';
import { openRazorpay } from '../payments';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { colors, gradients, radius } from '../theme';
import { LinearGradient } from 'expo-linear-gradient';

export default function CheckoutScreen({ navigation }) {
  const cart = useCart();
  const auth = useAuth();
  const { loadProducts } = useData();
  const insets = useSafeAreaInsets();
  const [f, setF] = useState({ customerName: '', phone: '', email: '', pincode: '', address: '', message: '' });
  const [method, setMethod] = useState('online');
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState('');
  const [status, setStatus] = useState(null);
  const [done, setDone] = useState(null);
  const set = (k, v) => { setF((c) => ({ ...c, [k]: v })); setErrors((e) => ({ ...e, [k]: undefined })); };
  useEffect(() => { if (auth.email && !f.email) set('email', auth.email); }, [auth.email]); // eslint-disable-line
  useEffect(() => { if (cart.hasDigital) setMethod('online'); }, [cart.hasDigital]);

  const validate = () => {
    const e = {};
    if (!f.customerName.trim()) e.customerName = 'Enter your name';
    if (!/^\d{10}$/.test(f.phone.replace(/[\s()+-]/g, ''))) e.phone = 'Enter a 10-digit mobile number';
    if (!/^\S+@\S+\.\S+$/.test(f.email.trim())) e.email = 'Enter a valid email address';
    if (!/^\d{6}$/.test(f.pincode.replace(/\s/g, ''))) e.pincode = 'Enter a valid 6-digit PIN code';
    if (!f.address.trim()) e.address = 'Enter your delivery address';
    setErrors(e);
    return !Object.keys(e).length;
  };

  const place = async () => {
    setStatus(null);
    if (!validate()) { setStatus({ type: 'error', text: 'Please fix the highlighted fields.' }); return; }
    if (method === 'cod' && cart.hasDigital) { setStatus({ type: 'error', text: 'Digital products require online payment.' }); return; }
    setBusy('Creating your order…');
    try {
      const payload = { ...f, customerName: f.customerName.trim(), email: f.email.trim(), method, items: cart.lines.map((l) => ({ product_id: l.product.id, quantity: l.quantity })) };
      const result = await storeApi.createOrder(payload);
      if (result.method !== method) throw new Error('Payment method mismatch. Do not pay; contact support with order ID ' + result.orderId);
      setBusy('Waiting for payment…');
      const paid = await openRazorpay({ key: result.keyId, amount: result.amount, description: 'Store order ' + result.orderId, order_id: result.razorpayOrderId, prefill: { name: payload.customerName, email: payload.email, contact: payload.phone } });
      setBusy('Payment received. Confirming your order…');
      let v;
      try { v = await storeApi.verifyOrder({ ...paid, orderId: result.orderId }); }
      catch (e) { throw new Error('Payment received but confirmation needs support review. Order ID: ' + result.orderId + '. ' + (e.message || '')); }
      setDone({ orderId: result.orderId, total: result.total, advance: result.advance, method, downloads: v.downloads || [], name: payload.customerName });
      cart.clear();
      loadProducts(true);
    } catch (e) {
      setStatus({ type: 'error', text: e.message || 'Checkout failed. Please try again.' });
    } finally { setBusy(''); }
  };

  const Head = (
    <View style={[styles.head, { paddingTop: insets.top + 8 }]}>
      <Pressable onPress={() => navigation.goBack()} accessibilityRole="button" accessibilityLabel="Back" hitSlop={8} style={styles.backBtn}><Ionicons name="arrow-back" size={22} color={colors.navy} /></Pressable>
      <Text style={styles.headTitle} accessibilityRole="header">{done ? 'Order confirmed' : 'Checkout'}</Text>
      <View style={{ width: 44 }} />
    </View>
  );

  if (done) {
    return (
      <Screen header={Head} bottomPad={60}>
        <View style={{ padding: 16 }}>
          <LinearGradient colors={gradients.brand} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.hero}>
            <View style={styles.check}><Ionicons name="checkmark" size={36} color={colors.teal} /></View>
            <Text style={styles.heroTitle}>Thank you, {done.name.split(' ')[0]}!</Text>
            <Text style={styles.heroSub}>Your payment was verified successfully.</Text>
          </LinearGradient>
          <Card style={{ marginTop: 16 }}>
            <View style={styles.kv}><Text style={styles.k}>Order ID</Text><Text style={styles.v} selectable>{done.orderId}</Text></View>
            <View style={styles.kv}><Text style={styles.k}>Order total</Text><Text style={styles.v}>{money(done.total)}</Text></View>
            <View style={styles.kv}><Text style={styles.k}>Payment</Text><Text style={styles.v}>{done.method === 'cod' ? `Cash on delivery (${money(done.advance)} advance paid)` : 'Paid online'}</Text></View>
          </Card>
          {done.downloads.length > 0 ? (
            <Card style={{ marginTop: 16, gap: 10 }}>
              <Text style={styles.sec}>Your digital downloads</Text>
              {done.downloads.map((d) => <DownloadButton key={d.productId} item={d} />)}
            </Card>
          ) : null}
          <View style={{ gap: 10, marginTop: 18 }}>
            <Btn title="View in My Account" icon="person" onPress={() => navigation.navigate('Tabs', { screen: 'Account' })} />
            <Btn title="Continue shopping" variant="outline" onPress={() => navigation.navigate('Tabs', { screen: 'Store' })} />
          </View>
        </View>
      </Screen>
    );
  }

  if (!cart.lines.length) {
    return <Screen header={Head}><View style={{ padding: 30 }}><Text style={{ color: colors.muted, textAlign: 'center' }}>Your cart is empty.</Text><Btn title="Go to store" onPress={() => navigation.navigate('Tabs', { screen: 'Store' })} style={{ marginTop: 16 }} variant="navy" /></View></Screen>;
  }

  return (
    <Screen header={Head} keyboard bottomPad={60}>
      <View style={{ padding: 16 }}>
        {status ? <Notice type={status.type}>{status.text}</Notice> : null}
        {busy ? <Notice type="info">{busy}</Notice> : null}
        <Card>
          <Text style={styles.sec}>Order summary</Text>
          {cart.lines.map(({ product: p, quantity }) => (
            <View key={p.id} style={styles.kv}><Text style={[styles.k, { flex: 1, width: undefined }]} numberOfLines={1}>{quantity} × {p.name}</Text><Text style={styles.v}>{money(p.price * quantity)}</Text></View>
          ))}
          <View style={[styles.kv, { borderBottomWidth: 0 }]}><Text style={[styles.k, { color: colors.navy, fontWeight: '800' }]}>Subtotal</Text><Text style={[styles.v, { fontSize: 18 }]}>{money(cart.subtotal)}</Text></View>
          <Text style={styles.fine}>Shipping and the final total are confirmed securely by the server when you place the order.</Text>
        </Card>

        <Card style={{ marginTop: 16 }}>
          <Text style={styles.sec}>Delivery details</Text>
          <Field label="Full name *" value={f.customerName} onChangeText={(v) => set('customerName', v)} error={errors.customerName} autoCapitalize="words" textContentType="name" />
          <Field label="Mobile number *" value={f.phone} onChangeText={(v) => set('phone', v)} keyboardType="phone-pad" error={errors.phone} textContentType="telephoneNumber" />
          <Field label="Email *" value={f.email} onChangeText={(v) => set('email', v)} keyboardType="email-address" autoCapitalize="none" autoCorrect={false} error={errors.email} textContentType="emailAddress" />
          <Field label="PIN code *" value={f.pincode} onChangeText={(v) => set('pincode', v.replace(/\D/g, '').slice(0, 6))} keyboardType="number-pad" maxLength={6} error={errors.pincode} textContentType="postalCode" />
          <Field label="Delivery address *" value={f.address} onChangeText={(v) => set('address', v)} multiline maxLength={500} error={errors.address} textContentType="fullStreetAddress" />
          <Field label="Note (optional)" value={f.message} onChangeText={(v) => set('message', v)} multiline maxLength={500} />
        </Card>

        <Card style={{ marginTop: 16 }}>
          <Text style={styles.sec}>Payment method</Text>
          {[['online', 'Pay online', 'Cards, UPI, netbanking via Razorpay', 'card-outline'], ['cod', 'Cash on delivery', '₹50 advance online, balance on delivery (orders of ₹50+ only)', 'cash-outline']].map(([id, t, sub, icon]) => {
            const disabled = id === 'cod' && cart.hasDigital;
            const on = method === id;
            return (
              <Pressable key={id} disabled={disabled} onPress={() => setMethod(id)} accessibilityRole="radio" accessibilityState={{ selected: on, disabled }} style={[styles.pay, on && styles.payOn, disabled && { opacity: 0.45 }]}>
                <Ionicons name={icon} size={24} color={on ? colors.teal : colors.navy} />
                <View style={{ flex: 1, marginHorizontal: 12 }}><Text style={styles.payTitle}>{t}</Text><Text style={styles.paySub}>{disabled ? 'Not available for digital products' : sub}</Text></View>
                <Ionicons name={on ? 'radio-button-on' : 'radio-button-off'} size={24} color={on ? colors.teal : '#B8C2D8'} />
              </Pressable>
            );
          })}
        </Card>

        <Btn title={method === 'cod' ? 'Pay ₹50 advance & place order' : 'Pay & place order'} icon="lock-closed" onPress={place} loading={!!busy} style={{ marginTop: 20 }} />
        <Text style={[styles.fine, { textAlign: 'center', marginTop: 12 }]}>Card and UPI details are entered on Razorpay's secure screen. NutriMedi never sees or stores them.</Text>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 14, paddingBottom: 8 },
  backBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  headTitle: { color: colors.navy, fontSize: 22, fontWeight: '800' },
  sec: { color: colors.navy, fontSize: 18, fontWeight: '800', marginBottom: 12 },
  kv: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 9, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.line },
  k: { color: colors.muted, fontWeight: '600', width: 110 },
  v: { color: colors.navy, fontWeight: '700', flex: 1, textAlign: 'right' },
  fine: { color: colors.muted, fontSize: 12.5, lineHeight: 18, marginTop: 8 },
  pay: { flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderColor: colors.line, borderRadius: radius.md, padding: 14, marginBottom: 10, backgroundColor: '#fff' },
  payOn: { borderColor: colors.teal, backgroundColor: colors.softTeal },
  payTitle: { color: colors.navy, fontWeight: '800', fontSize: 15.5 },
  paySub: { color: colors.muted, fontSize: 12.5, marginTop: 2, lineHeight: 17 },
  hero: { borderRadius: 30, padding: 28, alignItems: 'center' },
  check: { width: 72, height: 72, borderRadius: 36, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  heroTitle: { color: '#fff', fontSize: 25, fontWeight: '800', marginTop: 16 },
  heroSub: { color: '#D6E3F4', marginTop: 6 }
});
