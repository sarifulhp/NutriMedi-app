import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import * as SecureStore from 'expo-secure-store';
import { accountApi } from '../api';

const KEY_TOKEN = 'nm_account_token';
const KEY_EMAIL = 'nm_account_email';
const Ctx = createContext(null);

// Customer session. The token is stored in the device keychain / keystore (SecureStore), never in plain storage.
export function AuthProvider({ children }) {
  const [state, setState] = useState({ ready: false, token: '', email: '' });

  useEffect(() => {
    (async () => {
      try {
        const [token, email] = await Promise.all([SecureStore.getItemAsync(KEY_TOKEN), SecureStore.getItemAsync(KEY_EMAIL)]);
        setState({ ready: true, token: token || '', email: email || '' });
      } catch (_) { setState({ ready: true, token: '', email: '' }); }
    })();
  }, []);

  const requestOtp = useCallback((email) => accountApi.requestOtp(email.trim().toLowerCase()), []);

  const verifyOtp = useCallback(async (email, otp) => {
    const res = await accountApi.verifyOtp(email.trim().toLowerCase(), otp.trim());
    if (!res.token) throw new Error('The server did not return a login session.');
    const em = res.email || email.trim().toLowerCase();
    await SecureStore.setItemAsync(KEY_TOKEN, res.token);
    await SecureStore.setItemAsync(KEY_EMAIL, em);
    setState({ ready: true, token: res.token, email: em });
  }, []);

  const clear = useCallback(async () => {
    try { await SecureStore.deleteItemAsync(KEY_TOKEN); await SecureStore.deleteItemAsync(KEY_EMAIL); } catch (_) {}
    setState({ ready: true, token: '', email: '' });
  }, []);

  const logout = useCallback(async () => {
    const t = state.token;
    await clear();
    if (t) { try { await accountApi.logout(t); } catch (_) { /* session already cleared locally */ } }
  }, [state.token, clear]);

  const value = useMemo(() => ({ ...state, signedIn: !!state.token, requestOtp, verifyOtp, logout, expire: clear }), [state, requestOtp, verifyOtp, logout, clear]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export const useAuth = () => useContext(Ctx);
