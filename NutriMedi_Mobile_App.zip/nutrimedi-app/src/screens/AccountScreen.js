import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { ArticleCard } from '../components/ArticleCard';
import DownloadButton from '../components/DownloadButton';
import { Btn, Card, Empty, ErrorBox, Field, Notice, PageHeader, Screen, Skeleton, money, useToast } from '../components/UI';
import { accountApi } from '../api';
import { useAuth } from '../context/AuthContext';
import { useBookmarks } from '../context/BookmarksContext';
import { colors, gradients, radius } from '../theme';

const pick = (o, ...keys) => { for (const k of keys) if (o && o[k] !== undefined && o[k] !== null && o[k] !== '') return o[k]; return ''; };
const prettyDate = (v) => { if (!v) return ''; const d = new Date(v); return isNaN(d.getTime()) ? String(v) : d.toDateString(); };

function StatusPill({ text }) {
  const t = String(text || '').toLowerCase();
  const ok = /paid|confirm|deliver|success|captured/.test(t), bad = /cancel|fail|refund/.test(t);
  return <View style={[styles.pill, { backgroundColor: ok ? colors.softSuccess : bad ? colors.softDanger : colors.softOrange }]}><Text style={[styles.pillText, { color: ok ? colors.success : bad ? colors.danger : '#9A4A12' }]}>{text || 'Pending'}</Text></View>;
}

export default function AccountScreen({ navigation }) {
  const auth = useAuth();
  if (!auth.ready) return <Screen header={<PageHeader icon="person" title="My Account" />}><View style={{ padding: 20 }}><Skeleton height={200} radiusPx={24} /></View></Screen>;
  return auth.signedIn ? <Dashboard navigation={navigation} /> : <Login />;
}

// ------------------------------------------------------------------ passwordless email OTP login (same flow as the website)
function Login() {
  const auth = useAuth();
  const [step, setStep] = useState('email');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);

  const send = async () => {
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) { setMsg({ type: 'error', text: 'Enter a valid email address.' }); return; }
    setBusy(true); setMsg(null);
    try { await auth.requestOtp(email); setStep('otp'); setMsg({ type: 'success', text: 'We sent a one-time verification code to your email.' }); }
    catch (e) { setMsg({ type: 'error', text: e.message }); }
    finally { setBusy(false); }
  };
  const verify = async () => {
    if (otp.trim().length < 4) { setMsg({ type: 'error', text: 'Enter the verification code from your email.' }); return; }
    setBusy(true); setMsg(null);
    try { await auth.verifyOtp(email, otp); }
    catch (e) { setMsg({ type: 'error', text: e.message }); setBusy(false); }
  };

  return (
    <Screen keyboard bottomPad={120} header={<PageHeader icon="person" title="My Account" subtitle="Sign in securely to see your appointments and store orders." />}>
      <View style={{ padding: 16 }}>
        <Card>
          <LinearGradient colors={gradients.cool} style={styles.lockIcon}><Ionicons name="mail" size={26} color="#fff" /></LinearGradient>
          <Text style={styles.cardTitle}>Sign in or create an account</Text>
          <Text style={styles.cardSub}>Enter your email address. We’ll send a one-time verification code — no password needed.</Text>
          {msg ? <Notice type={msg.type}>{msg.text}</Notice> : null}
          <Field label="Email address" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" autoCorrect={false} editable={step === 'email'} textContentType="emailAddress" autoComplete="email" />
          {step === 'otp' ? (
            <>
              <Field label="Verification code" value={otp} onChangeText={(v) => setOtp(v.replace(/\s/g, ''))} placeholder="Enter code" keyboardType="number-pad" maxLength={8} textContentType="oneTimeCode" autoComplete="sms-otp" />
              <Btn title="Verify and sign in" icon="log-in" onPress={verify} loading={busy} />
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 14 }}>
                <Pressable onPress={() => { setStep('email'); setOtp(''); setMsg(null); }} hitSlop={8}><Text style={styles.link}>Change email</Text></Pressable>
                <Pressable onPress={send} hitSlop={8}><Text style={styles.link}>Resend code</Text></Pressable>
              </View>
            </>
          ) : <Btn title="Send verification code" icon="send" onPress={send} loading={busy} />}
          <Text style={styles.fine}>Your appointments and orders are shown only after email verification.</Text>
        </Card>
      </View>
    </Screen>
  );
}

// ------------------------------------------------------------------ dashboard
function Dashboard({ navigation }) {
  const auth = useAuth();
  const saved = useBookmarks();
  const toast = useToast();
  const [tab, setTab] = useState('appointments');
  const [data, setData] = useState({ orders: [], appointments: [], loading: true, error: '' });
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    setData((d) => ({ ...d, error: '' }));
    try {
      const [o, a] = await Promise.all([accountApi.myOrders(auth.token), accountApi.myAppointments(auth.token)]);
      setData({ orders: Array.isArray(o.orders) ? o.orders : [], appointments: Array.isArray(a.appointments) ? a.appointments : [], loading: false, error: '' });
    } catch (e) {
      if (e.status === 401 || /session|sign in|log in|token/i.test(e.message || '')) { toast.show('Your session expired. Please sign in again.'); auth.expire(); return; }
      setData((d) => ({ ...d, loading: false, error: e.message }));
    }
  }, [auth, toast]);
  useEffect(() => { load(); }, []); // eslint-disable-line
  const refresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const confirmLogout = () => Alert.alert('Sign out', 'Do you want to sign out of NutriMedi?', [{ text: 'Cancel', style: 'cancel' }, { text: 'Sign out', style: 'destructive', onPress: () => auth.logout() }]);

  return (
    <Screen onRefresh={refresh} refreshing={refreshing} bottomPad={120} header={(
      <PageHeader icon="person" title="My Account" subtitle={auth.email}
        right={<Pressable onPress={confirmLogout} accessibilityRole="button" accessibilityLabel="Sign out" style={styles.logout}><Ionicons name="log-out-outline" size={22} color="#fff" /></Pressable>} />
    )}>
      <View style={styles.stats}>
        {[['calendar', data.appointments.length, 'Appointments', colors.teal], ['bag-handle', data.orders.length, 'Orders', colors.purple], ['bookmark', saved.items.length, 'Saved', colors.orange]].map(([ic, n, l, c]) => (
          <View key={l} style={[styles.stat, { borderTopColor: c }]}><Ionicons name={ic} size={20} color={c} /><Text style={styles.statNum}>{n}</Text><Text style={styles.statLabel}>{l}</Text></View>
        ))}
      </View>
      <View style={styles.tabs}>
        {[['appointments', 'Appointments'], ['orders', 'Orders'], ['saved', 'Saved']].map(([k, l]) => (
          <Pressable key={k} onPress={() => setTab(k)} accessibilityRole="tab" accessibilityState={{ selected: tab === k }} style={[styles.tab, tab === k && styles.tabOn]}><Text style={[styles.tabText, tab === k && { color: '#fff' }]}>{l}</Text></Pressable>
        ))}
      </View>
      <View style={{ paddingHorizontal: 16, gap: 14 }}>
        {tab !== 'saved' && data.loading ? <><Skeleton height={120} radiusPx={22} /><Skeleton height={120} radiusPx={22} /></> : null}
        {tab !== 'saved' && data.error ? <ErrorBox message={data.error} onRetry={load} /> : null}

        {tab === 'appointments' && !data.loading && !data.error ? (data.appointments.length ? data.appointments.map((a, i) => <AppointmentCard key={String(a.booking_id || i)} a={a} />)
          : <Empty icon="calendar-outline" title="No appointments yet" message="Booked appointments will appear here." action="Book an appointment" onAction={() => navigation.navigate('Appointment')} />) : null}

        {tab === 'orders' && !data.loading && !data.error ? (data.orders.length ? data.orders.map((o, i) => <OrderCard key={String(pick(o, 'order_id', 'orderId') || i)} o={o} token={auth.token} />)
          : <Empty icon="bag-handle-outline" title="No orders yet" message="Your store orders will appear here." action="Browse the store" onAction={() => navigation.navigate('Store')} />) : null}

        {tab === 'saved' ? (saved.items.length ? saved.items.map((a) => (
          <View key={a.slug}>
            <ArticleCard a={a} onPress={() => navigation.navigate('Article', { slug: a.slug, preview: { ...a, contentHtml: '' } })} />
            <Pressable onPress={() => saved.toggle(a)} accessibilityRole="button" accessibilityLabel={'Remove saved article ' + a.title} style={styles.unsave}><Ionicons name="bookmark" size={16} color="#fff" /><Text style={styles.unsaveText}>Remove</Text></Pressable>
          </View>
        )) : <Empty icon="bookmark-outline" title="No saved articles" message="Tap the bookmark on any article to keep it here. Saved articles are stored on this device." action="Read articles" onAction={() => navigation.navigate('Articles')} />) : null}
      </View>
    </Screen>
  );
}

function AppointmentCard({ a }) {
  const serial = pick(a, 'serial_number', 'Serial_Number', 'serial');
  return (
    <Card style={{ padding: 16 }}>
      <View style={styles.cardTop}>
        <View style={styles.serial}><Text style={styles.serialLabel}>SERIAL</Text><Text style={styles.serialNo}>{serial ? String(serial).padStart(3, '0') : '—'}</Text></View>
        <View style={{ flex: 1, marginLeft: 14 }}>
          <Text style={styles.cardHead}>{pick(a, 'service') || 'Appointment'}</Text>
          <Text style={styles.cardLine}>{prettyDate(pick(a, 'booking_date', 'date'))}</Text>
          <Text style={styles.cardLine}>{pick(a, 'consultation_method', 'mode')}</Text>
        </View>
      </View>
      <View style={styles.pills}><StatusPill text={pick(a, 'appointment_status', 'status')} /><StatusPill text={pick(a, 'payment_status') && 'Payment: ' + pick(a, 'payment_status')} /></View>
    </Card>
  );
}

function OrderCard({ o, token }) {
  const [open, setOpen] = useState(false);
  const [dl, setDl] = useState(null);
  const [dlBusy, setDlBusy] = useState(false);
  const [dlErr, setDlErr] = useState('');
  const id = String(pick(o, 'order_id', 'orderId'));
  const total = pick(o, 'total_amount', 'total', 'orderTotal');
  const items = Array.isArray(o.items) ? o.items : [];
  const loadDownloads = async () => {
    setDlBusy(true); setDlErr('');
    try { const r = await accountApi.downloads(token, id); setDl(Array.isArray(r.downloads) ? r.downloads : []); }
    catch (e) { setDlErr(e.message); }
    finally { setDlBusy(false); }
  };
  return (
    <Card style={{ padding: 16 }}>
      <Pressable onPress={() => setOpen((v) => !v)} accessibilityRole="button" accessibilityState={{ expanded: open }}>
        <View style={styles.cardTop}>
          <View style={{ flex: 1 }}>
            <Text style={styles.cardHead} numberOfLines={1}>{id}</Text>
            <Text style={styles.cardLine}>{prettyDate(pick(o, 'order_date', 'created_at'))}</Text>
          </View>
          <Text style={styles.total}>{total !== '' ? money(total) : ''}</Text>
          <Ionicons name={open ? 'chevron-up' : 'chevron-down'} size={20} color={colors.muted} style={{ marginLeft: 8 }} />
        </View>
        <View style={styles.pills}><StatusPill text={pick(o, 'order_status', 'status')} /><StatusPill text={pick(o, 'payment_status') && 'Payment: ' + pick(o, 'payment_status')} /></View>
      </Pressable>
      {open ? (
        <View style={{ marginTop: 14, gap: 8 }}>
          {items.map((it, i) => (
            <View key={i} style={styles.itemRow}><Text style={styles.itemName} numberOfLines={2}>{pick(it, 'quantity', 'Quantity') || 1} × {pick(it, 'product_name', 'name', 'productId') || 'Item'}</Text>{pick(it, 'subtotal', 'price') !== '' ? <Text style={styles.itemPrice}>{money(pick(it, 'subtotal', 'price'))}</Text> : null}</View>
          ))}
          {dl === null ? <Btn title="Check digital downloads" icon="download-outline" variant="outline" small onPress={loadDownloads} loading={dlBusy} /> : dl.length ? dl.map((d) => <DownloadButton key={d.productId} item={d} />) : <Text style={styles.cardLine}>No digital products in this order.</Text>}
          {dlErr ? <Text style={{ color: colors.danger, fontSize: 13 }}>{dlErr}</Text> : null}
        </View>
      ) : null}
    </Card>
  );
}

const styles = StyleSheet.create({
  lockIcon: { width: 56, height: 56, borderRadius: 18, alignItems: 'center', justifyContent: 'center', marginBottom: 14 },
  cardTitle: { color: colors.navy, fontSize: 21, fontWeight: '800' },
  cardSub: { color: colors.muted, fontSize: 14.5, lineHeight: 21, marginTop: 6, marginBottom: 16 },
  link: { color: colors.teal, fontWeight: '800', fontSize: 14.5 },
  fine: { color: colors.muted, fontSize: 12.5, marginTop: 14, lineHeight: 18 },
  logout: { width: 46, height: 46, borderRadius: 15, backgroundColor: 'rgba(255,255,255,.18)', alignItems: 'center', justifyContent: 'center' },
  stats: { flexDirection: 'row', gap: 10, paddingHorizontal: 16, marginTop: 16 },
  stat: { flex: 1, backgroundColor: '#fff', borderRadius: radius.md, paddingVertical: 14, alignItems: 'center', borderTopWidth: 5, shadowColor: '#142B59', shadowOpacity: 0.08, shadowRadius: 8, shadowOffset: { width: 0, height: 3 }, elevation: 2 },
  statNum: { color: colors.navy, fontSize: 24, fontWeight: '800', marginTop: 4 },
  statLabel: { color: colors.muted, fontSize: 12, fontWeight: '600' },
  tabs: { flexDirection: 'row', backgroundColor: colors.softNavy, borderRadius: 999, padding: 4, margin: 16 },
  tab: { flex: 1, paddingVertical: 11, borderRadius: 999, alignItems: 'center' },
  tabOn: { backgroundColor: colors.navy },
  tabText: { color: colors.navy, fontWeight: '800', fontSize: 14 },
  cardTop: { flexDirection: 'row', alignItems: 'center' },
  cardHead: { color: colors.navy, fontWeight: '800', fontSize: 16 },
  cardLine: { color: colors.muted, fontSize: 13.5, marginTop: 2 },
  total: { color: colors.teal, fontWeight: '800', fontSize: 17 },
  pills: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  pill: { borderRadius: 999, paddingHorizontal: 12, paddingVertical: 5 },
  pillText: { fontWeight: '800', fontSize: 12 },
  serial: { width: 74, height: 74, borderRadius: 20, backgroundColor: colors.softPurple, alignItems: 'center', justifyContent: 'center' },
  serialLabel: { color: colors.purple, fontSize: 10, fontWeight: '800', letterSpacing: 1.2 },
  serialNo: { color: colors.purple, fontSize: 26, fontWeight: '800' },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 },
  itemName: { flex: 1, color: colors.text, fontSize: 14.5 },
  itemPrice: { color: colors.navy, fontWeight: '700' },
  unsave: { position: 'absolute', right: 14, top: 14, flexDirection: 'row', alignItems: 'center', backgroundColor: colors.orange, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 6 },
  unsaveText: { color: '#fff', fontWeight: '800', fontSize: 12, marginLeft: 5 }
});
