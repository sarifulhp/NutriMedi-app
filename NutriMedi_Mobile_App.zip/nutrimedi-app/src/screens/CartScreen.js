import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Btn, Card, Empty, RemoteImage, Screen, money } from '../components/UI';
import { useCart } from '../context/CartContext';
import { catTheme } from '../utils/articleFormat';
import { colors, radius, themes } from '../theme';

export default function CartScreen({ navigation }) {
  const cart = useCart();
  const insets = useSafeAreaInsets();
  const Head = (
    <View style={[styles.head, { paddingTop: insets.top + 8 }]}>
      <Pressable onPress={() => navigation.goBack()} accessibilityRole="button" accessibilityLabel="Back" hitSlop={8} style={styles.backBtn}><Ionicons name="arrow-back" size={22} color={colors.navy} /></Pressable>
      <Text style={styles.headTitle} accessibilityRole="header">Your cart</Text>
      <View style={{ width: 44 }} />
    </View>
  );
  if (!cart.lines.length) {
    return <Screen header={Head}><Empty icon="bag-handle-outline" title="Your cart is empty" message="Browse the store to add wellness essentials and digital resources." action="Go to store" onAction={() => navigation.navigate('Tabs', { screen: 'Store' })} /></Screen>;
  }
  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <Screen header={Head} bottomPad={190}>
        <View style={{ padding: 16, gap: 14 }}>
          {cart.lines.map(({ product: p, quantity }) => {
            const th = themes[catTheme(p.category)];
            const max = Math.min(20, p.stock === null ? 20 : p.stock);
            return (
              <Card key={p.id} style={styles.line}>
                <RemoteImage uri={p.image} grad={th.grad} icon="bag-handle" style={styles.img} />
                <View style={{ flex: 1, marginLeft: 14 }}>
                  <Text numberOfLines={2} style={styles.name}>{p.name}</Text>
                  <Text style={styles.price}>{money(p.price)}</Text>
                  <View style={styles.ctrl}>
                    <View style={styles.stepper}>
                      <Pressable onPress={() => cart.setQty(p.id, quantity - 1)} hitSlop={6} accessibilityLabel={`Decrease ${p.name}`} style={styles.stepBtn}><Ionicons name="remove" size={18} color={colors.navy} /></Pressable>
                      <Text style={styles.qty}>{quantity}</Text>
                      <Pressable onPress={() => cart.setQty(p.id, Math.min(max, quantity + 1))} hitSlop={6} accessibilityLabel={`Increase ${p.name}`} style={styles.stepBtn}><Ionicons name="add" size={18} color={colors.navy} /></Pressable>
                    </View>
                    <Pressable onPress={() => cart.remove(p.id)} hitSlop={10} accessibilityRole="button" accessibilityLabel={`Remove ${p.name}`}><Ionicons name="trash-outline" size={22} color={colors.danger} /></Pressable>
                  </View>
                </View>
              </Card>
            );
          })}
        </View>
      </Screen>
      <View style={[styles.bar, { paddingBottom: insets.bottom + 14 }]}>
        <View style={styles.sumRow}><Text style={styles.sumLabel}>Subtotal ({cart.count} {cart.count === 1 ? 'item' : 'items'})</Text><Text style={styles.sumValue}>{money(cart.subtotal)}</Text></View>
        <Text style={styles.fine}>Shipping and the final total are calculated securely at checkout.</Text>
        <Btn title="Checkout" icon="lock-closed" onPress={() => navigation.navigate('Checkout')} style={{ marginTop: 10 }} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 14, paddingBottom: 8 },
  backBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  headTitle: { color: colors.navy, fontSize: 22, fontWeight: '800' },
  line: { flexDirection: 'row', padding: 12 },
  img: { width: 84, height: 84, borderRadius: 18 },
  name: { color: colors.navy, fontWeight: '800', fontSize: 15.5, lineHeight: 20 },
  price: { color: colors.teal, fontWeight: '800', fontSize: 16, marginTop: 4 },
  ctrl: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 },
  stepper: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.softNavy, borderRadius: 999 },
  stepBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  qty: { minWidth: 24, textAlign: 'center', fontWeight: '800', color: colors.navy },
  bar: { position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: '#fff', padding: 18, borderTopLeftRadius: 28, borderTopRightRadius: 28, shadowColor: '#142B59', shadowOpacity: 0.15, shadowRadius: 18, shadowOffset: { width: 0, height: -6 }, elevation: 12 },
  sumRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  sumLabel: { color: colors.muted, fontWeight: '600', fontSize: 15 },
  sumValue: { color: colors.navy, fontWeight: '800', fontSize: 22 },
  fine: { color: colors.muted, fontSize: 12.5, marginTop: 4 }
});
