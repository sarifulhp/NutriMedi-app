import React, { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react';
import { articlesApi, storeApi } from '../api';

const Ctx = createContext(null);

// Shared, cached lists so screens do not re-download the same data (keeps API calls low).
export function DataProvider({ children }) {
  const [articles, setArticles] = useState({ items: [], loading: true, error: '', loaded: false });
  const [products, setProducts] = useState({ items: [], loading: true, error: '', loaded: false });
  const aLast = useRef(0), pLast = useRef(0), aBusy = useRef(false), pBusy = useRef(false);
  const FRESH = 60 * 1000;

  const loadArticles = useCallback(async (force = false) => {
    if (aBusy.current || (!force && aLast.current && Date.now() - aLast.current < FRESH)) return;
    aBusy.current = true;
    setArticles((s) => ({ ...s, loading: !s.loaded || force, error: '' }));
    try {
      const items = await articlesApi.list();
      aLast.current = Date.now();
      setArticles({ items, loading: false, error: '', loaded: true });
    } catch (e) { setArticles((s) => ({ ...s, loading: false, error: e.message })); }
    finally { aBusy.current = false; }
  }, []);

  const loadProducts = useCallback(async (force = false) => {
    if (pBusy.current || (!force && pLast.current && Date.now() - pLast.current < FRESH)) return;
    pBusy.current = true;
    setProducts((s) => ({ ...s, loading: !s.loaded || force, error: '' }));
    try {
      const items = await storeApi.products();
      pLast.current = Date.now();
      setProducts({ items, loading: false, error: '', loaded: true });
    } catch (e) { setProducts((s) => ({ ...s, loading: false, error: e.message })); }
    finally { pBusy.current = false; }
  }, []);

  const value = useMemo(() => ({ articles, products, loadArticles, loadProducts }), [articles, products, loadArticles, loadProducts]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export const useData = () => useContext(Ctx);
