import { request, ApiError } from './http';
import { API_BASE } from '../config';
import { readyArticle } from '../utils/articleFormat';

// ---------- Articles (public) ----------
export const articlesApi = {
  async list() {
    const d = await request('/api/articles');
    return (d.articles || []).map(readyArticle).sort((a, b) => String(b.time).localeCompare(String(a.time)));
  },
  async get(slug) {
    const d = await request('/api/articles?slug=' + encodeURIComponent(slug));
    if (!d.article) throw new ApiError('Article not found', 404);
    return readyArticle(d.article);
  }
};

// ---------- Store ----------
export function normalizeProduct(p) {
  const id = String(p.product_id ?? p.Product_ID ?? p.id ?? p.sku ?? p.name ?? '');
  const price = Number(p.price ?? p.Price ?? p.selling_price ?? p.sale_price ?? 0);
  const stockRaw = p.stock ?? p.Stock ?? p.quantity ?? p.stock_quantity;
  const stock = stockRaw === undefined || stockRaw === null || stockRaw === '' || !Number.isFinite(Number(stockRaw)) ? null : Number(stockRaw);
  return {
    id,
    name: String(p.name ?? p.Name ?? p.product_name ?? p.title ?? 'Untitled product'),
    price: Number.isFinite(price) ? price : 0,
    category: String(p.category ?? p.Category ?? p.product_category ?? 'General').trim() || 'General',
    description: String(p.description ?? p.Description ?? '').trim(),
    image: String(p.image_url ?? p.Image_URL ?? p.image ?? p.photo ?? '').trim(),
    stock,
    type: String(p.type ?? p.Type ?? p.product_type ?? 'physical').toLowerCase(),
    badge: String(p.badge ?? p.Badge ?? '').trim()
  };
}
export const storeApi = {
  async products() {
    const d = await request('/api/products');
    return (d.products || []).map(normalizeProduct).filter((p) => p.id);
  },
  createOrder: (payload) => request('/api/order-create', { method: 'POST', body: payload }),
  verifyOrder: (payload) => request('/api/order-verify', { method: 'POST', body: payload })
};

// ---------- Appointments ----------
export const bookingApi = {
  create: (payload) => request('/api/booking-create', { method: 'POST', body: payload }),
  async verify(payload) {
    const result = await request('/api/booking-verify', { method: 'POST', body: payload });
    const info = result.result || result.data || result.booking || result;
    const id = info.booking_id || info.bookingId || result.booking_id;
    const serial = info.serial ?? info.serialNumber ?? info.serial_number ?? result.serial;
    const date = info.date || info.bookingDate || info.booking_date || result.date;
    if (!id || serial === undefined || serial === null || serial === '' || !date) {
      throw new ApiError('Payment received, but confirmation details are missing. Do not pay again; contact support.', 502);
    }
    return { bookingId: id, serial: String(serial).padStart(3, '0'), date };
  }
};

// ---------- Customer account (passwordless email OTP, token based – same as the website) ----------
const account = (action, data = {}) => request('/api/account', { method: 'POST', body: { action, ...data } });
export const accountApi = {
  requestOtp: (email) => account('requestOtp', { email }),
  verifyOtp: (email, otp) => account('verifyOtp', { email, otp }),
  myOrders: (token) => account('myOrders', { token }),
  myAppointments: (token) => account('myAppointments', { token }),
  orderDetails: (token, orderId) => account('orderDetails', { token, orderId }),
  downloads: (token, orderId) => account('downloads', { token, orderId }),
  logout: (token) => account('logout', { token })
};

// Digital PDF download: POST returns a PDF; we convert it to base64 so it can be saved and shared.
export async function fetchDigitalPdfBase64(token) {
  const res = await request('/api/digital-download', { method: 'POST', body: { token }, raw: true });
  if (!res.ok) throw new ApiError('Download unavailable. Verify your order or contact support.', res.status);
  const blob = await res.blob();
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onerror = () => reject(new ApiError('Could not read the downloaded file.', 0));
    r.onloadend = () => resolve(String(r.result).split(',')[1] || '');
    r.readAsDataURL(blob);
  });
}

// ---------- Admin (cookie session, protected by the existing backend) ----------
export const adminApi = {
  login: (email, password) => request('/api/admin-login', { method: 'POST', body: { email, password } }),
  async session() {
    const d = await request('/api/admin-session');
    return !!d.authenticated;
  },
  logout: () => request('/api/admin-logout', { method: 'POST', body: {} }),
  bookings: async () => (await request('/api/admin', { method: 'POST', body: { action: 'adminList' } })).bookings || [],
  setBookingStatus: (serial_no, status) => request('/api/admin', { method: 'POST', body: { action: 'status', serial_no, status } }),
  orders: async () => (await request('/api/admin', { method: 'POST', body: { action: 'storeOrders' } })).orders || [],
  setOrderStatus: (order_id, status) => request('/api/admin', { method: 'POST', body: { action: 'storeStatus', order_id, status } }),
  articles: async () => (await request('/api/admin-articles', { method: 'POST', body: { action: 'list' } })).articles || [],
  saveArticle: (article) => request('/api/admin-articles', { method: 'POST', body: { action: article.id ? 'update' : 'create', article } }),
  publishArticle: (id) => request('/api/admin-articles', { method: 'POST', body: { action: 'publish', id } }),
  unpublishArticle: (id) => request('/api/admin-articles', { method: 'POST', body: { action: 'unpublish', id } }),
  deleteArticle: (id) => request('/api/admin-articles', { method: 'POST', body: { action: 'delete', id } })
};

export { ApiError, API_BASE };
