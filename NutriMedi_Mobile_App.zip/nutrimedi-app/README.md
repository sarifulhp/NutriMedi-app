# NutriMedi mobile app (Android + iOS)

A native React Native (Expo) companion to https://www.nutrimedi.in. It talks to the **same Vercel API** the website uses
(`/api/articles`, `/api/products`, `/api/booking-create`, `/api/booking-verify`, `/api/order-create`, `/api/order-verify`,
`/api/account`, `/api/digital-download`, `/api/admin*`). **No backend, Google Sheet, Apps Script or `vercel.json` change is needed.**

## What is in the app
| Area | What it does |
|---|---|
| Bottom tabs | Home · Articles · Appointment · Store · Account (menu icon on Home opens About, Contact, Policies) |
| Home | Featured article, popular topics (built from real categories), booking shortcut, latest articles, store picks, search |
| Articles | Magazine list, search, category filters, featured card, save/bookmark |
| Article reader | Full-bleed cover, reading-progress bar, coloured section cards, numbered tips, check-lists, highlight quotes, fact/tip/warning callouts, before/after cards, images, tables, scroll-reveal, related articles, WhatsApp / Facebook / Copy link / system share. English and Bengali. Raw Markdown (`###`, `**`, `---`) is removed; wording is never changed |
| Appointment | Service, date, session, method, validation → create booking → Razorpay ₹10 → verify → real serial number |
| Store | Search, categories, product page, cart (saved on device), checkout (online or COD with ₹50 advance, same rules as the website), digital PDF downloads |
| Account | Passwordless email-OTP sign-in (same as the website), appointments, orders (with downloads), saved articles, sign out |
| Admin | Hidden entry (see below). Appointments + status, store orders + status, articles list/new/edit/save draft/publish/unpublish/delete |

## Requirements
* Node.js 20+ and npm
* An Expo account (free) for cloud builds: https://expo.dev
* Optional for local builds: Android Studio (Android) or a Mac with Xcode (iOS)
* For the iOS App Store: an Apple Developer account. For Google Play: a Play Console account.

## 1) Install
```bash
cd nutrimedi-app
npm install
npx expo install --fix      # aligns every package to the exact versions of the pinned Expo SDK
npm run test:format         # 13 quick checks of the article formatter (plain Node)
```

## 2) Try it on a phone (fast, no payments)
```bash
npx expo start
```
Scan the QR code with the **Expo Go** app. Everything works in Expo Go **except Razorpay payments**, because
`react-native-razorpay` is a native module. In Expo Go the app shows "Payments need the installed NutriMedi app build"
and nothing is charged.

## 3) Build a real app (payments work)
### Cloud build with EAS (no Android Studio / Xcode needed)
```bash
npm install -g eas-cli
eas login
eas build:configure                 # first time only
eas build -p android --profile preview      # installable .apk you can share
eas build -p android --profile production   # .aab for Google Play
eas build -p ios --profile production       # needs the Apple Developer account
```
### Local development build
```bash
npx expo run:android      # needs Android Studio + a phone/emulator
npx expo run:ios          # needs a Mac with Xcode
```
Test payments with **Razorpay TEST keys** on the Vercel project first (a ₹10 booking, then a store order), then switch to live keys.

## 4) Point at another backend (optional)
Copy `.env.example` to `.env` and change `EXPO_PUBLIC_API_BASE`. Default is https://www.nutrimedi.in.

## Admin access
The admin screens use the website's own login (`/api/admin-login`, 30-minute cookie session). They are not shown to normal users:
the **Menu → Admin** row appears only if a valid admin session already exists, or after tapping the version text at the bottom
of the Menu five times. Every admin request is checked by the backend, so hiding the row is only a convenience.

## Things the existing backend does not provide (so the app does not fake them)
* **Passwords, registration, forgot-password, profile editing** – the website is passwordless email-OTP, so the app is too.
* **Saved articles** – stored on the phone only (there is no bookmark endpoint).
* **"Popular articles" ranking** – the Sheet has no view counts. The app shows "Popular topics" (categories by article count) and "Latest articles".
* **Admin user management, reports, push notifications** – no such endpoints exist yet.

## Before publishing to the stores
* **Apple requires in-app account deletion** for apps that let people create accounts. The backend has no delete-account endpoint yet; add one (or contact Apple review with your plan) before submitting to the App Store.
* Add store listing assets (screenshots), a support URL and the Privacy Policy URL: https://www.nutrimedi.in/privacy-policy.html
* Change `ios.bundleIdentifier` / `android.package` in `app.json` if you want an ID other than `in.nutrimedi.app`.
* Health-information disclaimers are shown in the article reader and Menu; keep them.

## Project layout
```
App.js                      providers + navigation
app.json / eas.json         Expo and EAS configuration
src/config.js               API base URL, contact details, services, session slots
src/theme.js                NutriMedi colours, gradients, shadows
src/api/                    http client + endpoint wrappers (mirror the website's calls)
src/utils/articleFormat.js  DOM-free article cleaner / sectioner (tested by scripts/test-format.mjs)
src/context/                auth (SecureStore), cart, bookmarks, cached data
src/components/             reusable UI, article cards, rich article blocks, product card
src/screens/                all screens incl. admin
src/navigation/             tabs + stack + deep links (nutrimedi://articles/<slug>)
```
