import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { FlatList, ScrollView, StyleSheet, Text, View } from 'react-native';
import { ArticleCard, FeaturedCard } from '../components/ArticleCard';
import { Chip, Empty, ErrorBox, PageHeader, SearchBar, SectionHeader, Skeleton } from '../components/UI';
import { useData } from '../context/DataContext';
import { useBookmarks } from '../context/BookmarksContext';
import { catTheme, plain } from '../utils/articleFormat';
import { Ionicons } from '@expo/vector-icons';
import { Pressable } from 'react-native';
import { colors, themes } from '../theme';

export default function ArticlesScreen({ navigation, route }) {
  const { articles, loadArticles } = useData();
  const saved = useBookmarks();
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { loadArticles(); }, [loadArticles]);
  // Home screen can deep-link into a search or a category.
  useEffect(() => {
    if (route.params && route.params.q !== undefined) setQ(route.params.q || '');
    if (route.params && route.params.category !== undefined) setCat(route.params.category || '');
  }, [route.params]);

  const items = articles.items;
  const cats = useMemo(() => {
    const c = {};
    items.forEach((a) => { if (a.category) c[a.category] = (c[a.category] || 0) + 1; });
    return Object.keys(c).sort((x, y) => c[y] - c[x] || x.localeCompare(y)).map((k) => ({ name: k, count: c[k] }));
  }, [items]);

  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return items.filter((a) => {
      if (cat && a.category !== cat) return false;
      if (!needle) return true;
      if (!a._hay) a._hay = (a.title + ' ' + a.excerpt + ' ' + a.category + ' ' + a.keywords + ' ' + a.author + ' ' + plain(a.contentHtml)).toLowerCase();
      return a._hay.indexOf(needle) > -1;
    });
  }, [items, q, cat]);

  const filtering = !!(q.trim() || cat);
  const featured = !filtering ? rows[0] : null;
  const list = featured ? rows.slice(1) : rows;
  const open = (a) => navigation.navigate('Article', { slug: a.slug, preview: a });

  const refresh = useCallback(async () => { setRefreshing(true); await loadArticles(true); setRefreshing(false); }, [loadArticles]);

  const header = (
    <View>
      <PageHeader icon="book" title="Articles" subtitle="Practical reading on food, nutrition and healthier living." />
      <View style={{ paddingHorizontal: 16, marginTop: -22 }}>
        <SearchBar value={q} onChangeText={setQ} placeholder="Search articles…" />
      </View>
      {cats.length > 0 ? (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 16 }}>
          <Chip label="All" count={items.length} active={!cat} onPress={() => setCat('')} />
          {cats.map((c) => <Chip key={c.name} label={c.name} count={c.count} active={cat === c.name} onPress={() => setCat(c.name)} grad={themes[catTheme(c.name)].grad} />)}
        </ScrollView>
      ) : <View style={{ height: 14 }} />}
      {featured ? <View style={{ paddingHorizontal: 16 }}><FeaturedCard a={featured} onPress={() => open(featured)} /></View> : null}
      {!articles.loading && items.length > 0 ? (
        <SectionHeader title={filtering ? (rows.length + (rows.length === 1 ? ' article found' : ' articles found')) : 'Latest articles'} />
      ) : null}
    </View>
  );

  let empty = null;
  if (articles.loading && !items.length) {
    empty = <View style={{ padding: 16, gap: 16 }}><Skeleton height={250} radiusPx={24} /><Skeleton height={250} radiusPx={24} /></View>;
  } else if (articles.error && !items.length) {
    empty = <ErrorBox message={articles.error} onRetry={() => loadArticles(true)} />;
  } else if (!items.length) {
    empty = <Empty title="Fresh articles are on the way" message="No articles have been published yet. Please check back soon." />;
  } else if (!rows.length) {
    empty = <Empty icon="search-outline" title="No matching articles" message="Try a different word, or clear the filters." action="Clear filters" onAction={() => { setQ(''); setCat(''); }} />;
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <FlatList
        data={list}
        keyExtractor={(a) => a.slug}
        ListHeaderComponent={header}
        ListEmptyComponent={featured ? null : empty}
        renderItem={({ item }) => (
          <View style={{ paddingHorizontal: 16, marginBottom: 18 }}>
            <ArticleCard a={item} onPress={() => open(item)} />
            {saved.isSaved(item.slug) ? <View style={styles.savedPill}><Ionicons name="bookmark" size={13} color="#fff" /></View> : null}
          </View>
        )}
        refreshing={refreshing}
        onRefresh={refresh}
        initialNumToRender={4}
        windowSize={7}
        removeClippedSubviews
        contentContainerStyle={{ paddingBottom: 110 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  savedPill: { position: 'absolute', right: 30, top: 14, backgroundColor: colors.orange, borderRadius: 999, width: 28, height: 28, alignItems: 'center', justifyContent: 'center' }
});
