import React, { useEffect, useRef, useState } from 'react';
import { Linking, Platform, Pressable, Share, StyleSheet, Text, View } from 'react-native';
import DateTimePicker, { DateTimePickerAndroid } from '@react-native-community/datetimepicker';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { Btn, Card, Field, Notice, PageHeader, Screen } from '../components/UI';
import { bookingApi } from '../api';
import { openRazorpay } from '../payments';
import { useAuth } from '../context/AuthContext';
import { CONTACT, SERVICES, SLOTS } from '../config';
import { colors, gradients, radius, shadow } from '../theme';

const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
// The server validates the date against India time, so "today" is computed the same way.
const istToday = () => { const [y, m, d] = new Date(Date.now() + 19800000).toISOString().slice(0, 10).split('-').map(Number); return new Date(y, m - 1, d); };
const prettyDate = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d).toDateString(); };

export default function AppointmentScreen({ navigation }) {
  const auth = useAuth();
  const [f, setF] = useState({ name: '', phone: '', email: '', service: '', date: '', slot: '', mode: '', message: '' });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState('');
  const [status, setStatus] = useState(null); // {type,text}
  const [receipt, setReceipt] = useState(null);
  const [showIosPicker, setShowIosPicker] = useState(false);
  const topRef = useRef(null);
  const set = (k, v) => { setF((c) => ({ ...c, [k]: v })); setErrors((e) => ({ ...e, [k]: undefined })); };

  useEffect(() => { if (auth.email && !f.email) set('email', auth.email); }, [auth.email]); // eslint-disable-line

  const pickDate = () => {
    const min = istToday();
    const current = f.date ? new Date(f.date + 'T00:00:00') : min;
    if (Platform.OS === 'android') {
      DateTimePickerAndroid.open({ value: current, mode: 'date', minimumDate: min, onChange: (e, d) => { if (e.type === 'set' && d) set('date', ymd(d)); } });
    } else setShowIosPicker((v) => !v);
  };

  const validate = () => {
    const e = {};
    if (!f.name.trim()) e.name = 'Enter your full name'; else if (f.name.length > 120) e.name = 'Name is too long';
    if (!/^\d{10}$/.test(f.phone.trim())) e.phone = 'Enter a 10-digit mobile number';
    if (!/^\S+@\S+\.\S+$/.test(f.email.trim())) e.email = 'Enter a valid email address';
    if (!f.service) e.service = 'Choose a service';
    if (!f.date) e.date = 'Choose a date'; else if (f.date < ymd(istToday())) e.date = 'Choose today or a future date';
    if (!f.slot) e.slot = 'Choose a session';
    if (!f.mode) e.mode = 'Choose a consultation method';
    if (f.message.length > 1500) e.message = 'Message is too long (max 1500 characters)';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async () => {
    setStatus(null);
    if (!validate()) { setStatus({ type: 'error', text: 'Please fix the highlighted fields.' }); return; }
    setBusy('Creating your booking…');
    try {
      const order = await bookingApi.create({ name: f.name.trim(), phone: f.phone.trim(), email: f.email.trim(), service: f.service, date: f.date, slot: f.slot, mode: f.mode, message: f.message.trim() });
      setBusy('Waiting for payment…');
      const payment = await openRazorpay({ key: order.key_id, amount: order.amount, description: 'Appointment booking fee ₹10', order_id: order.order_id, prefill: { name: f.name.trim(), email: f.email.trim(), contact: f.phone.trim() } });
      setBusy('Payment received. Verifying your booking…');
      let result;
      try { result = await bookingApi.verify({ ...payment, booking_id: order.booking_id }); }
      catch (e) { throw new Error('Payment may have succeeded but booking confirmation failed. Do not pay again. Check My Account or contact support. ' + (e.message || '')); }
      const svc = SERVICES.find((s) => s.id === f.service);
      setReceipt({ ...result, name: f.name.trim(), phone: f.phone.trim(), email: f.email.trim(), service: svc ? svc.label : f.service, mode: f.mode, slot: SLOTS.find((s) => s.id === f.slot), paymentId: payment.razorpay_payment_id });
    } catch (e) {
      setStatus({ type: 'error', text: e.message || 'Booking failed. Please try again.' });
    } finally { setBusy(''); }
  };

  const reset = () => { setReceipt(null); setStatus(null); setF({ name: '', phone: '', email: auth.email || '', service: '', date: '', slot: '', mode: '', message: '' }); };

  if (receipt) {
    const text = `NutriMedi appointment confirmed\nSerial: ${receipt.serial}\nName: ${receipt.name}\nService: ${receipt.service}\nDate: ${prettyDate(receipt.date)}\nSession: ${receipt.slot ? receipt.slot.title + ' (' + receipt.slot.time + ')' : ''}\nMethod: ${receipt.mode}\nBooking ID: ${receipt.bookingId}\nPayment ID: ${receipt.paymentId}`;
    return (
      <Screen header={<PageHeader icon="checkmark-circle" title="Booking confirmed" subtitle="Your payment was verified and your serial number is ready." />} bottomPad={120}>
        <View style={{ padding: 16 }}>
          <LinearGradient colors={gradients.cool} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[styles.serial, shadow.lg]}>
            <Text style={styles.serialLabel}>YOUR SERIAL</Text>
            <Text style={styles.serialNo} accessibilityLabel={`Serial number ${receipt.serial}`}>{receipt.serial}</Text>
          </LinearGradient>
          <Card style={{ marginTop: 16 }}>
            {[['Name', receipt.name], ['Mobile', receipt.phone], ['Email', receipt.email], ['Service', receipt.service], ['Date', prettyDate(receipt.date)], ['Session', receipt.slot ? `${receipt.slot.title} · ${receipt.slot.time}` : ''], ['Method', receipt.mode], ['Booking ID', receipt.bookingId], ['Payment ID', receipt.paymentId]].map(([k, v]) => (
              <View key={k} style={styles.kv}><Text style={styles.k}>{k}</Text><Text style={styles.v} selectable>{v}</Text></View>
            ))}
          </Card>
          <View style={{ gap: 10, marginTop: 16 }}>
            <Btn title="Share booking details" icon="share-social" onPress={() => Share.share({ message: text })} />
            <Btn title="View in My Account" icon="person" variant="navy" onPress={() => navigation.navigate('Account')} />
            <Btn title="Book another appointment" variant="outline" onPress={reset} />
          </View>
        </View>
      </Screen>
    );
  }

  return (
    <Screen keyboard header={<PageHeader icon="calendar" title="Book an appointment" subtitle="Choose a session, share your details and confirm with a secure ₹10 booking payment." />} bottomPad={130}>
      <View ref={topRef} style={{ padding: 16 }}>
        {status ? <Notice type={status.type}>{status.text}</Notice> : null}
        {busy ? <Notice type="info">{busy}</Notice> : null}

        <Card>
          <Text style={styles.cardTitle}>Your details</Text>
          <Field label="Full name *" value={f.name} onChangeText={(v) => set('name', v)} placeholder="Enter your full name" error={errors.name} autoCapitalize="words" textContentType="name" autoComplete="name" />
          <Field label="Mobile number *" value={f.phone} onChangeText={(v) => set('phone', v.replace(/\D/g, '').slice(0, 10))} placeholder="10-digit mobile number" keyboardType="number-pad" maxLength={10} error={errors.phone} textContentType="telephoneNumber" autoComplete="tel" />
          <Field label="Email address *" value={f.email} onChangeText={(v) => set('email', v)} placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" autoCorrect={false} error={errors.email} hint="Booking confirmation is sent here." textContentType="emailAddress" autoComplete="email" />
        </Card>

        <Card style={{ marginTop: 16 }}>
          <Text style={styles.cardTitle}>Service *</Text>
          <View style={styles.grid}>
            {SERVICES.map((s) => {
              const on = f.service === s.id;
              return (
                <Pressable key={s.id} onPress={() => set('service', s.id)} accessibilityRole="radio" accessibilityState={{ selected: on }} style={[styles.svc, on && styles.svcOn]}>
                  <View style={[styles.svcIcon, on && { backgroundColor: colors.teal }]}><Ionicons name={s.icon} size={22} color={on ? '#fff' : colors.teal} /></View>
                  <Text style={[styles.svcText, on && { color: colors.teal }]}>{s.label}</Text>
                </Pressable>
              );
            })}
          </View>
          {errors.service ? <Text style={styles.err}>{errors.service}</Text> : null}
        </Card>

        <Card style={{ marginTop: 16 }}>
          <Text style={styles.cardTitle}>Date & session *</Text>
          <Pressable onPress={pickDate} accessibilityRole="button" accessibilityLabel="Choose appointment date" style={[styles.dateBtn, !!errors.date && { borderColor: colors.danger }]}>
            <Ionicons name="calendar-outline" size={22} color={colors.purple} />
            <Text style={[styles.dateText, !f.date && { color: '#9AA6C0' }]}>{f.date ? prettyDate(f.date) : 'Choose a date'}</Text>
          </Pressable>
          {errors.date ? <Text style={styles.err}>{errors.date}</Text> : null}
          {Platform.OS === 'ios' && showIosPicker ? (
            <DateTimePicker value={f.date ? new Date(f.date + 'T00:00:00') : istToday()} mode="date" display="inline" minimumDate={istToday()} accentColor={colors.purple} onChange={(e, d) => { if (d) set('date', ymd(d)); }} />
          ) : null}
          <View style={{ marginTop: 14, gap: 10 }}>
            {SLOTS.map((s) => {
              const on = f.slot === s.id;
              return (
                <Pressable key={s.id} onPress={() => set('slot', s.id)} accessibilityRole="radio" accessibilityState={{ selected: on }} style={[styles.slot, on && styles.slotOn]}>
                  <View style={styles.slotIcon}><Ionicons name={s.icon} size={24} color={colors.orange} /></View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.slotTitle}>{s.title}</Text>
                    <Text style={styles.slotSub}>{s.time} · {s.serials}</Text>
                  </View>
                  <Ionicons name={on ? 'radio-button-on' : 'radio-button-off'} size={24} color={on ? colors.teal : '#B8C2D8'} />
                </Pressable>
              );
            })}
          </View>
          {errors.slot ? <Text style={styles.err}>{errors.slot}</Text> : null}
          <Text style={styles.hint}>Serial numbers are issued after verified payment, subject to availability.</Text>
        </Card>

        <Card style={{ marginTop: 16 }}>
          <Text style={styles.cardTitle}>Consultation method *</Text>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            {['Online', 'Offline'].map((m) => {
              const on = f.mode === m;
              return (
                <Pressable key={m} onPress={() => set('mode', m)} accessibilityRole="radio" accessibilityState={{ selected: on }} style={[styles.mode, on && styles.modeOn]}>
                  <Ionicons name={m === 'Online' ? 'videocam-outline' : 'location-outline'} size={20} color={on ? '#fff' : colors.navy} />
                  <Text style={[styles.modeText, on && { color: '#fff' }]}>{m}</Text>
                </Pressable>
              );
            })}
          </View>
          {errors.mode ? <Text style={styles.err}>{errors.mode}</Text> : null}
          <Field label="Message (optional)" value={f.message} onChangeText={(v) => set('message', v)} placeholder="Tell us about your nutrition goals" multiline maxLength={1500} error={errors.message} style={{ marginTop: 16 }} />
        </Card>

        <Btn title="Pay ₹10 & confirm booking" icon="lock-closed" onPress={submit} loading={!!busy} style={{ marginTop: 20 }} />
        <Text style={styles.fine}>Secure payment by Razorpay. No booking is confirmed until payment is verified.</Text>
        <Pressable onPress={() => Linking.openURL(CONTACT.whatsapp)} style={styles.wa} accessibilityRole="button">
          <Ionicons name="logo-whatsapp" size={20} color="#fff" /><Text style={styles.waText}>Need help? WhatsApp {CONTACT.phoneLabel}</Text>
        </Pressable>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  cardTitle: { color: colors.navy, fontSize: 18, fontWeight: '800', marginBottom: 14 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  svc: { width: '48%', borderWidth: 1.5, borderColor: colors.line, borderRadius: radius.md, padding: 14, backgroundColor: '#fff' },
  svcOn: { borderColor: colors.teal, backgroundColor: colors.softTeal },
  svcIcon: { width: 40, height: 40, borderRadius: 13, backgroundColor: colors.softTeal, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  svcText: { color: colors.navy, fontWeight: '700', fontSize: 14.5 },
  dateBtn: { flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderColor: colors.line, borderRadius: radius.md, padding: 15, backgroundColor: '#fff' },
  dateText: { marginLeft: 12, fontSize: 16, color: colors.navy, fontWeight: '600' },
  slot: { flexDirection: 'row', alignItems: 'center', borderWidth: 2, borderColor: colors.line, borderRadius: 20, padding: 14, backgroundColor: '#fff' },
  slotOn: { borderColor: colors.teal, backgroundColor: colors.softTeal },
  slotIcon: { width: 46, height: 46, borderRadius: 15, backgroundColor: colors.softOrange, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  slotTitle: { color: colors.navy, fontWeight: '800', fontSize: 16 },
  slotSub: { color: colors.muted, fontSize: 13, marginTop: 2 },
  mode: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderWidth: 1.5, borderColor: colors.line, borderRadius: radius.pill, paddingVertical: 14, backgroundColor: '#fff' },
  modeOn: { backgroundColor: colors.navy, borderColor: colors.navy },
  modeText: { color: colors.navy, fontWeight: '800', fontSize: 15 },
  err: { color: colors.danger, fontSize: 13, fontWeight: '600', marginTop: 8 },
  hint: { color: colors.muted, fontSize: 12.5, marginTop: 12 },
  fine: { color: colors.muted, fontSize: 12.5, textAlign: 'center', marginTop: 12 },
  wa: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#1FAF55', borderRadius: 999, paddingVertical: 14, marginTop: 16, gap: 8 },
  waText: { color: '#fff', fontWeight: '800' },
  serial: { borderRadius: radius.xl, padding: 26, alignItems: 'center' },
  serialLabel: { color: '#E4ECFB', fontWeight: '800', letterSpacing: 2, fontSize: 12 },
  serialNo: { color: '#fff', fontSize: 64, fontWeight: '800', marginTop: 6 },
  kv: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 9, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.line },
  k: { color: colors.muted, fontWeight: '600', width: 100 },
  v: { color: colors.navy, fontWeight: '700', flex: 1, textAlign: 'right' }
});
