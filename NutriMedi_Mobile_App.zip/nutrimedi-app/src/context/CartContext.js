import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'nm_cart_v1';
const Ctx = createContext(null);

// Cart lines: { product, quantity }. Prices are re-checked by the server when the order is created.
export function CartProvider({ children }) {
  const [lines, setLines] = useState([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(KEY).then((raw) => { try { const v = JSON.parse(raw || '[]'); if (Array.isArray(v)) setLines(v); } catch (_) {} }).finally(() => setReady(true));
  }, []);
  useEffect(() => { if (ready) AsyncStorage.setItem(KEY, JSON.stringify(lines)).catch(() => {}); }, [lines, ready]);

  const maxFor = (p) => Math.min(20, p.stock === null || p.stock === undefined ? 20 : Math.max(0, p.stock));

  const add = useCallback((product, qty = 1) => {
    setLines((cur) => {
      const found = cur.find((l) => l.product.id === product.id);
      const next = Math.min(maxFor(product), (found ? found.quantity : 0) + qty);
      if (next < 1) return cur;
      return found ? cur.map((l) => (l.product.id === product.id ? { product, quantity: next } : l)) : [...cur, { product, quantity: next }];
    });
  }, []);
  const setQty = useCallback((id, qty) => setLines((cur) => cur.flatMap((l) => {
    if (l.product.id !== id) return [l];
    const q = Math.min(maxFor(l.product), qty);
    return q < 1 ? [] : [{ ...l, quantity: q }];
  })), []);
  const remove = useCallback((id) => setLines((cur) => cur.filter((l) => l.product.id !== id)), []);
  const clear = useCallback(() => setLines([]), []);

  const value = useMemo(() => ({
    lines, ready, add, setQty, remove, clear,
    count: lines.reduce((s, l) => s + l.quantity, 0),
    subtotal: lines.reduce((s, l) => s + l.quantity * l.product.price, 0),
    hasDigital: lines.some((l) => l.product.type === 'digital')
  }), [lines, ready, add, setQty, remove, clear]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export const useCart = () => useContext(Ctx);
