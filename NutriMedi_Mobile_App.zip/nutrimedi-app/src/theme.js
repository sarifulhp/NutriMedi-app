export const colors = {
  navy: '#142B59', teal: '#087F78', purple: '#7657D6', orange: '#F47B36', pink: '#E94F91',
  bg: '#F7F9FC', white: '#FFFFFF', text: '#33476B', muted: '#657391', line: '#E3E9F3',
  softTeal: '#E3F5F3', softPurple: '#EEE9FB', softOrange: '#FEEEE3', softPink: '#FDE8F1', softNavy: '#E6EBF6',
  danger: '#B3263F', softDanger: '#FDE8EC', success: '#0B6B57', softSuccess: '#E4F7EF'
};
export const gradients = {
  brand: ['#142B59', '#087F78'],
  warm: ['#F47B36', '#E94F91'],
  cool: ['#7657D6', '#087F78'],
  purple: ['#7657D6', '#142B59']
};
// Colour themes used for categories and article sections (same idea as the website)
export const themes = {
  orange: { a: '#F47B36', soft: '#FEEEE3', grad: ['#F47B36', '#E94F91'] },
  teal: { a: '#087F78', soft: '#E3F5F3', grad: ['#087F78', '#0AA39A'] },
  purple: { a: '#7657D6', soft: '#EEE9FB', grad: ['#7657D6', '#9A6BFF'] },
  pink: { a: '#E94F91', soft: '#FDE8F1', grad: ['#E94F91', '#F27AA8'] },
  navy: { a: '#142B59', soft: '#E6EBF6', grad: ['#142B59', '#2C4F9E'] }
};
export const themeNames = ['orange', 'teal', 'purple', 'pink', 'navy'];
export const radius = { sm: 12, md: 18, lg: 24, xl: 30, pill: 999 };
export const shadow = {
  sm: { shadowColor: '#142B59', shadowOpacity: 0.08, shadowRadius: 8, shadowOffset: { width: 0, height: 3 }, elevation: 2 },
  md: { shadowColor: '#142B59', shadowOpacity: 0.12, shadowRadius: 16, shadowOffset: { width: 0, height: 8 }, elevation: 5 },
  lg: { shadowColor: '#142B59', shadowOpacity: 0.18, shadowRadius: 26, shadowOffset: { width: 0, height: 14 }, elevation: 9 }
};
