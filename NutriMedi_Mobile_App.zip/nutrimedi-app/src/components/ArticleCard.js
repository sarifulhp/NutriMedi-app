import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { RemoteImage } from './UI';
import { colors, radius, shadow, themes } from '../theme';
import { formatDate, initials } from '../utils/articleFormat';

function Meta({ a, light }) {
  const th = themes[a.theme];
  const date = formatDate(a.time);
  return (
    <View style={styles.meta}>
      <LinearGradient colors={th.grad} style={styles.av}><Text style={styles.avText}>{initials(a.author)}</Text></LinearGradient>
      <View style={{ flex: 1, marginHorizontal: 10 }}>
        <Text numberOfLines={1} style={[styles.author, light && { color: '#fff' }]}>{a.author}</Text>
        {date ? <Text style={[styles.date, light && { color: '#D6E2F6' }]}>{date}</Text> : null}
      </View>
      <View style={[styles.read, { backgroundColor: th.soft }]}><Text style={[styles.readText, { color: th.a }]}>{a.mins} min read</Text></View>
    </View>
  );
}

export function CategoryTag({ a, style }) {
  const th = themes[a.theme];
  return (
    <LinearGradient colors={th.grad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={[styles.tag, style]}>
      <Text numberOfLines={1} style={styles.tagText}>{a.category || 'Nutrition'}</Text>
    </LinearGradient>
  );
}

export function ArticleCard({ a, onPress, style }) {
  const th = themes[a.theme];
  return (
    <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel={'Read: ' + a.title} style={({ pressed }) => [styles.card, shadow.md, pressed && { transform: [{ scale: 0.985 }] }, style]}>
      <View>
        <RemoteImage uri={a.cover} grad={th.grad} style={styles.cover} />
        <CategoryTag a={a} style={{ position: 'absolute', left: 14, top: 14 }} />
      </View>
      <View style={styles.body}>
        <Text numberOfLines={3} style={[styles.title, a.bn && { lineHeight: 28 }]}>{a.title}</Text>
        {a.excerpt ? <Text numberOfLines={3} style={[styles.excerpt, a.bn && { lineHeight: 24 }]}>{a.excerpt}</Text> : null}
        <Meta a={a} />
      </View>
    </Pressable>
  );
}

export function FeaturedCard({ a, onPress }) {
  const th = themes[a.theme];
  return (
    <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel={'Featured article: ' + a.title} style={({ pressed }) => [styles.feat, shadow.lg, pressed && { transform: [{ scale: 0.985 }] }]}>
      <RemoteImage uri={a.cover} grad={th.grad} style={StyleSheet.absoluteFill} />
      <LinearGradient colors={['rgba(14,28,62,.35)', 'rgba(14,28,62,.15)', 'rgba(14,28,62,.88)', 'rgba(14,28,62,.97)']} locations={[0, 0.3, 0.72, 1]} style={StyleSheet.absoluteFill} />
      <View style={styles.featTop}>
        <LinearGradient colors={['#F47B36', '#E94F91']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.flag}><Ionicons name="star" size={12} color="#fff" /><Text style={styles.flagText}>Featured</Text></LinearGradient>
        <CategoryTag a={a} />
      </View>
      <View style={styles.featBottom}>
        <Text numberOfLines={3} style={[styles.featTitle, a.bn && { lineHeight: 36 }]}>{a.title}</Text>
        {a.excerpt ? <Text numberOfLines={2} style={[styles.featExcerpt, a.bn && { lineHeight: 23 }]}>{a.excerpt}</Text> : null}
        <Meta a={a} light />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: '#fff', borderRadius: radius.lg, overflow: 'hidden' },
  cover: { height: 176, width: '100%' },
  body: { padding: 18 },
  title: { color: colors.navy, fontSize: 19, fontWeight: '800', lineHeight: 25, letterSpacing: -0.3 },
  excerpt: { color: colors.muted, fontSize: 14.5, lineHeight: 21, marginTop: 8 },
  meta: { flexDirection: 'row', alignItems: 'center', marginTop: 16, paddingTop: 14, borderTopWidth: 1, borderTopColor: colors.line, borderStyle: 'dashed' },
  av: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  avText: { color: '#fff', fontWeight: '800', fontSize: 12 },
  author: { color: colors.navy, fontWeight: '700', fontSize: 13 },
  date: { color: colors.muted, fontSize: 12 },
  read: { borderRadius: 999, paddingHorizontal: 11, paddingVertical: 5 },
  readText: { fontWeight: '800', fontSize: 12 },
  tag: { borderRadius: 999, paddingHorizontal: 13, paddingVertical: 6, maxWidth: 200 },
  tagText: { color: '#fff', fontWeight: '800', fontSize: 12 },
  feat: { height: 400, borderRadius: radius.xl, overflow: 'hidden', backgroundColor: colors.navy },
  featTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16 },
  flag: { flexDirection: 'row', alignItems: 'center', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 6 },
  flagText: { color: '#fff', fontWeight: '800', fontSize: 12, marginLeft: 5 },
  featBottom: { position: 'absolute', left: 0, right: 0, bottom: 0, padding: 20 },
  featTitle: { color: '#fff', fontSize: 26, fontWeight: '800', lineHeight: 32, letterSpacing: -0.5 },
  featExcerpt: { color: '#E3ECFA', fontSize: 14.5, lineHeight: 21, marginTop: 8 }
});
