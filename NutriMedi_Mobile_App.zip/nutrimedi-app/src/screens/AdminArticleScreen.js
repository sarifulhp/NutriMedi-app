import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Btn, Card, Field, Notice, PageHeader, Screen, useToast } from '../components/UI';
import { adminApi } from '../api';
import { colors } from '../theme';

// Create / edit an article. Uses the existing /api/admin-articles contract (same fields as the website editor).
// The content box accepts HTML or plain text/Markdown; the reader cleans it up for display.
export default function AdminArticleScreen({ route, navigation }) {
  const existing = route.params && route.params.article;
  const toast = useToast();
  const [f, setF] = useState({
    id: existing ? existing.id : '', title: existing ? existing.title || '' : '', slug: existing ? existing.slug || '' : '', category: existing ? existing.category || '' : '',
    excerpt: existing ? existing.excerpt || '' : '', coverImage: existing ? existing.coverImage || '' : '', author: existing ? existing.author || '' : '',
    seoTitle: existing ? existing.seoTitle || '' : '', metaDescription: existing ? existing.metaDescription || '' : '', keywords: existing ? existing.keywords || '' : '',
    contentHtml: existing ? existing.contentHtml || '' : ''
  });
  const [busy, setBusy] = useState('');
  const [msg, setMsg] = useState(null);
  const set = (k, v) => setF((c) => ({ ...c, [k]: v }));

  const save = async (status) => {
    if (!f.title.trim() || !f.contentHtml.trim()) { setMsg({ type: 'error', text: 'Title and article content are required.' }); return; }
    setBusy(status); setMsg(null);
    try {
      const res = await adminApi.saveArticle({ ...f, status });
      if (res.id && !f.id) set('id', res.id);
      toast.show(status === 'published' ? 'Article published' : 'Draft saved');
      navigation.goBack();
    } catch (e) {
      if (e.status === 401) { setMsg({ type: 'error', text: 'Your admin session expired. Go back and sign in again.' }); return; }
      setMsg({ type: 'error', text: e.message });
    } finally { setBusy(''); }
  };

  return (
    <Screen keyboard bottomPad={80} header={<PageHeader icon="create" title={existing ? 'Edit article' : 'New article'} colorsOverride={['#142B59', '#7657D6']} right={<Pressable onPress={() => navigation.goBack()} accessibilityRole="button" accessibilityLabel="Close" style={{ width: 46, height: 46, borderRadius: 15, backgroundColor: 'rgba(255,255,255,.18)', alignItems: 'center', justifyContent: 'center' }}><Ionicons name="close" size={24} color="#fff" /></Pressable>} />}>
      <View style={{ padding: 16 }}>
        {msg ? <Notice type={msg.type}>{msg.text}</Notice> : null}
        <Card>
          <Field label="Title *" value={f.title} onChangeText={(v) => set('title', v)} />
          <Field label="Slug (optional)" value={f.slug} onChangeText={(v) => set('slug', v)} autoCapitalize="none" autoCorrect={false} hint="Leave blank to let the system create it." />
          <Field label="Category" value={f.category} onChangeText={(v) => set('category', v)} />
          <Field label="Author" value={f.author} onChangeText={(v) => set('author', v)} />
          <Field label="Short description" value={f.excerpt} onChangeText={(v) => set('excerpt', v)} multiline />
          <Field label="Cover image URL" value={f.coverImage} onChangeText={(v) => set('coverImage', v)} autoCapitalize="none" autoCorrect={false} keyboardType="url" />
          <Field label="Article content *" value={f.contentHtml} onChangeText={(v) => set('contentHtml', v)} multiline inputStyle={{ minHeight: 260 }} hint="HTML or plain text. Use headings, lists and short paragraphs for the best reading experience." />
        </Card>
        <Card style={{ marginTop: 16 }}>
          <Text style={{ color: colors.navy, fontWeight: '800', fontSize: 17, marginBottom: 12 }}>SEO (optional)</Text>
          <Field label="SEO title" value={f.seoTitle} onChangeText={(v) => set('seoTitle', v)} />
          <Field label="Meta description" value={f.metaDescription} onChangeText={(v) => set('metaDescription', v)} multiline />
          <Field label="Keywords" value={f.keywords} onChangeText={(v) => set('keywords', v)} />
        </Card>
        <View style={{ gap: 10, marginTop: 18 }}>
          <Btn title="Publish article" icon="rocket" variant="cool" onPress={() => save('published')} loading={busy === 'published'} disabled={!!busy} />
          <Btn title="Save draft" icon="save-outline" variant="navy" onPress={() => save('draft')} loading={busy === 'draft'} disabled={!!busy} />
        </View>
      </View>
    </Screen>
  );
}
