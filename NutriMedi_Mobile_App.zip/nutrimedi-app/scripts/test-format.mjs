// Run with: npm run test:format   (plain Node, no device needed)
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { pathToFileURL, fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nm-fmt-'));
fs.copyFileSync(path.join(root, 'src/theme.js'), path.join(tmp, 'theme.mjs'));
fs.writeFileSync(path.join(tmp, 'articleFormat.mjs'),
  fs.readFileSync(path.join(root, 'src/utils/articleFormat.js'), 'utf8').replace("from '../theme'", "from './theme.mjs'"));
const F = await import(pathToFileURL(path.join(tmp, 'articleFormat.mjs')).href);

let n = 0;
const ok = (name, fn) => { fn(); n++; console.log('  ✓', name); };

const bn = '<p>### কেন ভারসাম্য জরুরি?</p><p>**ভারসাম্যপূর্ণ খাবার** শরীরকে পুষ্টি দেয়।&nbsp;</p><p>&nbsp;</p><p><br></p>' +
  '<p>জানেন কি? প্রতিদিন পর্যাপ্ত পানি পান করলে হজম ভালো থাকে।</p><h2>প্রতিদিনের পরামর্শ</h2><ol><li>সকালে প্রোটিন রাখুন</li><li>সবজি বেশি খান</li></ol>' +
  '<p>টিপ: ছোট প্লেটে খেলে পরিমাণ নিয়ন্ত্রণে থাকে।</p><h2>যা এড়িয়ে চলবেন</h2><ul><li>অতিরিক্ত চিনি</li></ul><blockquote>সচেতনতাই প্রথম ধাপ।</blockquote>' +
  '<p>আগে: অনিয়মিত খাবার</p><p>পরে: নিয়মিত খাবার</p><p><img src="https://x.test/a.jpg" alt=""></p><h2>শেষ কথা</h2><p>*সতর্কতা: চিকিৎসকের পরামর্শ নিন।*</p>';

console.log('Bengali article with Markdown noise');
const s = F.buildSections(bn);
ok('splits into intro + 3 titled sections', () => { assert.equal(s.length, 4); assert.equal(s[0].plainTitle, ''); assert.deepEqual(s.slice(1).map((x) => x.plainTitle), ['প্রতিদিনের পরামর্শ', 'যা এড়িয়ে চলবেন', 'শেষ কথা']); });
ok('no raw markdown symbols survive', () => { const all = JSON.stringify(s); assert.ok(!/\*\*|###|&nbsp;/.test(all), all); });
ok('empty / nbsp paragraphs are dropped', () => { assert.ok(s[0].blocks.every((b) => !(b.t === 'p' && F.plain(b.html) === ''))); });
ok('### becomes a sub-heading, ** becomes bold', () => { assert.equal(s[0].blocks[0].t, 'h'); assert.ok(s[0].blocks.some((b) => b.t === 'p' && b.html.includes('<strong>ভারসাম্যপূর্ণ খাবার</strong>'))); });
ok('"জানেন কি?" becomes a fact callout', () => { const c = s[0].blocks.find((b) => b.t === 'callout'); assert.equal(c.kind, 'fact'); assert.equal(c.label, 'জানেন কি?'); assert.ok(c.html.startsWith('প্রতিদিন')); });
ok('ordered list kept, tip + quote + compare detected', () => { assert.equal(s[1].blocks[0].t, 'ol'); assert.equal(s[1].blocks[1].kind, 'tip'); assert.ok(s[2].blocks.some((b) => b.t === 'quote')); assert.ok(s[2].blocks.some((b) => b.t === 'compare')); });
ok('image kept, warning callout detected from *italic* label', () => { assert.ok(s[2].blocks.some((b) => b.t === 'img' && b.src === 'https://x.test/a.jpg')); assert.equal(s[3].blocks[0].kind, 'warn'); });

console.log('Plain-text Markdown article');
const md = '## Why iron matters\n\nIron helps carry **oxygen** in the blood.\n\n- Lentils\n- Spinach\n\n### Pair with vitamin C\n\n1. Squeeze lemon\n2. Add tomatoes\n\n---\n\nNote: Talk to a doctor.\n\n## Final\n\nSmall changes add up.';
const m = F.buildSections(md);
ok('sections, lists and rules', () => { assert.equal(m.length, 2); assert.equal(m[0].blocks[1].t, 'ul'); assert.deepEqual(m[0].blocks[1].items, ['Lentils', 'Spinach']); assert.equal(m[0].blocks[2].t, 'h'); assert.equal(m[0].blocks[3].t, 'ol'); assert.equal(m[0].blocks[4].kind, 'warn'); assert.ok(!JSON.stringify(m).includes('---')); });

console.log('Safety');
const evil = '<p>Hello <script>alert(1)</script><a href="javascript:alert(1)">bad</a> <a href="https://ok.test">good</a></p><iframe src="https://evil.test"></iframe><img src="javascript:alert(1)"><p onclick="x()">Fine &amp; safe &lt;b&gt;</p>';
const e = F.parseBlocks(evil);
ok('scripts, iframes, javascript: links/images are removed', () => { const j = JSON.stringify(e); assert.ok(!/script|alert|iframe|javascript:|evil/.test(j), j); assert.ok(j.includes('https://ok.test')); });
ok('entities are decoded once, never turned into markup', () => { const segs = F.toSegments(e[e.length - 1].html); assert.equal(segs.map((x) => x.text).join(''), 'Fine & safe <b>'); });
ok('inline segments carry bold / link info', () => { const segs = F.toSegments('<strong>A</strong> <a href="https://ok.test">B</a>'); assert.equal(segs[0].bold, true); assert.equal(segs[2].href, 'https://ok.test'); assert.equal(segs[2].underline, true); });

console.log('Helpers');
ok('reading time, theme and language detection', () => { assert.equal(F.readMins('<p>' + 'word '.repeat(380) + '</p>'), 2); assert.ok(F.isBengali('বাংলা')); assert.ok(!F.isBengali('English')); assert.equal(F.catTheme('Nutrition'), F.catTheme('Nutrition')); });
ok('empty content gives no sections', () => { assert.equal(F.buildSections('').length, 0); assert.equal(F.buildSections('<p>&nbsp;</p>').length, 0); });

console.log('\nAll ' + n + ' formatter checks passed');
fs.rmSync(tmp, { recursive: true, force: true });
