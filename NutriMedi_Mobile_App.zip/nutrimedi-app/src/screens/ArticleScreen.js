import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Animated, FlatList, Linking, Pressable, ScrollView, Share, StyleSheet, Text, View } from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { SectionCard } from '../components/ArticleBlocks';
import { ArticleCard } from '../components/ArticleCard';
import { Btn, ErrorBox, RemoteImage, Skeleton, useToast } from '../components/UI';
import { articlesApi } from '../api';
import { useData } from '../context/DataContext';
import { useBookmarks } from '../context/BookmarksContext';
import { SITE_URL } from '../config';
import { colors, radius, shadow, themes } from '../theme';
import { buildSections, formatDate, initials } from '../utils/articleFormat';

export default function ArticleScreen({ route, navigation }) {
  const { slug, preview } = route.params;
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const bookmarks = useBookmarks();
  const { articles, loadArticles } = useData();
  const [article, setArticle] = useState(preview && preview.contentHtml ? preview : null);
  const [error, setError] = useState('');
  const [revealed, setRevealed] = useState(() => new Set([0, 1]));
  const listRef = useRef(null);
  const progress = useRef(new Animated.Value(0)).current;
  const size = useRef({ content: 1, layout: 1 });

  // The list endpoint already carries full content, so a preview opens instantly with no extra request.
  const load = useCallback(async () => {
    setError('');
    try { setArticle(await articlesApi.get(slug)); } catch (e) { setError(e.message); }
  }, [slug]);
  useEffect(() => { if (!article) load(); }, [article, load]);
  useEffect(() => { loadArticles(); }, [loadArticles]);

  const sections = useMemo(() => (article ? buildSections(article.contentHtml) : []), [article]);
  const titled = sections.filter((s) => s.plainTitle);
  const url = SITE_URL + '/articles/' + encodeURIComponent(slug);

  const onViewable = useRef(({ viewableItems }) => {
    setRevealed((cur) => {
      const next = new Set(cur);
      viewableItems.forEach((v) => { if (v.index != null) next.add(v.index); });
      return next.size === cur.size ? cur : next;
    });
  }).current;
  const viewCfg = useRef({ itemVisiblePercentThreshold: 5 }).current;

  const onScroll = (e) => {
    const { contentOffset, contentSize, layoutMeasurement } = e.nativeEvent;
    const max = Math.max(1, contentSize.height - layoutMeasurement.height);
    progress.setValue(Math.min(1, Math.max(0, contentOffset.y / max)));
  };

  const shareWhatsApp = async () => {
    const text = encodeURIComponent(`${article.title} ${url}`);
    try { await Linking.openURL('whatsapp://send?text=' + text); } catch (_) { Linking.openURL('https://wa.me/?text=' + text).catch(() => toast.show('Could not open WhatsApp')); }
  };
  const shareFacebook = () => Linking.openURL('https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(url)).catch(() => toast.show('Could not open Facebook'));
  const copyLink = async () => { await Clipboard.setStringAsync(url); toast.show('Link copied'); };
  const shareMore = () => Share.share({ message: `${article.title}\n${url}`, url }).catch(() => {});

  if (!article) {
    return (
      <View style={styles.root}>
        <BackFab onPress={() => navigation.goBack()} top={insets.top + 8} />
        {error ? <View style={{ paddingTop: insets.top + 80 }}><ErrorBox message={error} onRetry={load} /></View>
          : <View style={{ padding: 20, paddingTop: insets.top + 70, gap: 14 }}><Skeleton height={380} radiusPx={30} /><Skeleton height={26} /><Skeleton height={26} width="70%" /></View>}
      </View>
    );
  }

  const th = themes[article.theme];
  const saved = bookmarks.isSaved(article.slug);
  const related = (() => {
    const others = articles.items.filter((a) => a.slug !== article.slug);
    const same = others.filter((a) => a.category && a.category === article.category);
    return same.concat(others.filter((a) => !same.includes(a))).slice(0, 3);
  })();
  let counter = 0;
  const numbers = sections.map((s) => (s.plainTitle ? ++counter : 0));

  const Hero = (
    <View>
      <View style={styles.hero}>
        <RemoteImage uri={article.cover} grad={th.grad} style={StyleSheet.absoluteFill} />
        <LinearGradient colors={['rgba(14,28,62,.58)', 'rgba(14,28,62,.25)', 'rgba(14,28,62,.8)', 'rgba(14,28,62,.97)']} locations={[0, 0.3, 0.64, 1]} style={StyleSheet.absoluteFill} />
        <View style={[styles.heroIn, { paddingTop: insets.top + 80 }]}>
          <LinearGradient colors={th.grad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.cat}><Text style={styles.catText}>{article.category || 'Nutrition'}</Text></LinearGradient>
          <Text style={[styles.title, article.bn && { lineHeight: 46, letterSpacing: 0 }]} accessibilityRole="header">{article.title}</Text>
          {article.excerpt ? <Text style={[styles.excerpt, article.bn && { lineHeight: 28 }]}>{article.excerpt}</Text> : null}
          <View style={styles.byline}>
            <LinearGradient colors={th.grad} style={styles.av}><Text style={styles.avText}>{initials(article.author)}</Text></LinearGradient>
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={styles.author}>{article.author}</Text>
              {formatDate(article.time) ? <Text style={styles.date}>{formatDate(article.time)}</Text> : null}
            </View>
            <View style={styles.pill}><Ionicons name="time-outline" size={14} color="#fff" /><Text style={styles.pillText}>{article.mins} min read</Text></View>
          </View>
        </View>
      </View>
      {titled.length >= 3 ? (
        <View style={[styles.toc, shadow.md]}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ alignItems: 'center', paddingHorizontal: 12 }}>
            <Text style={styles.tocLabel}>In this article</Text>
            {sections.map((s, i) => s.plainTitle ? (
              <Pressable key={s.id} onPress={() => listRef.current && listRef.current.scrollToIndex({ index: i, animated: true, viewOffset: 80 })} style={[styles.tocChip, { backgroundColor: th.soft }]}>
                <Text numberOfLines={1} style={[styles.tocText, { color: th.a }]}>{s.plainTitle}</Text>
              </Pressable>
            ) : null)}
          </ScrollView>
        </View>
      ) : null}
      <View style={{ height: 18 }} />
    </View>
  );

  const Footer = (
    <View style={{ paddingTop: 4 }}>
      <View style={[styles.share, shadow.md]}>
        <Text style={styles.shareTitle}>Found this useful? Share it.</Text>
        <Text style={styles.shareSub}>Send it to family and friends who might like it.</Text>
        <View style={{ gap: 10, marginTop: 16 }}>
          <Btn title="Share on WhatsApp" icon="logo-whatsapp" variant="whatsapp" onPress={shareWhatsApp} />
          <Btn title="Share on Facebook" icon="logo-facebook" onPress={shareFacebook} style={{ backgroundColor: '#1877F2' }} variant="navy" />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn title="Copy link" icon="link" variant="outline" onPress={copyLink} style={{ flex: 1 }} small />
            <Btn title="More" icon="share-social" variant="outline" onPress={shareMore} style={{ flex: 1 }} small />
          </View>
        </View>
      </View>
      <View style={styles.note}><Text style={styles.noteText}><Text style={{ fontWeight: '800' }}>Health information notice: </Text>This article is for general educational purposes. It does not replace diagnosis, treatment or advice from a qualified healthcare professional.</Text></View>
      {related.length > 0 ? (
        <View style={{ marginTop: 10 }}>
          <Text style={styles.relTitle}>Keep reading</Text>
          <View style={{ paddingHorizontal: 16, gap: 18 }}>
            {related.map((a) => <ArticleCard key={a.slug} a={a} onPress={() => navigation.push('Article', { slug: a.slug, preview: a })} />)}
          </View>
        </View>
      ) : null}
      <View style={{ padding: 20, paddingBottom: insets.bottom + 30 }}>
        <Btn title="Back to Articles" icon="arrow-back" variant="navy" onPress={() => navigation.navigate('Tabs', { screen: 'Articles' })} />
      </View>
    </View>
  );

  return (
    <View style={styles.root}>
      <FlatList
        ref={listRef}
        data={sections}
        keyExtractor={(s) => s.id}
        ListHeaderComponent={Hero}
        ListFooterComponent={Footer}
        ListEmptyComponent={<View style={styles.card0}><Text style={{ color: colors.muted, textAlign: 'center' }}>This article has no content yet.</Text></View>}
        renderItem={({ item, index }) => <SectionCard section={item} index={index} number={numbers[index]} revealed={revealed.has(index)} bn={article.bn} />}
        onScroll={onScroll}
        scrollEventThrottle={16}
        onViewableItemsChanged={onViewable}
        viewabilityConfig={viewCfg}
        onScrollToIndexFailed={(info) => { setTimeout(() => listRef.current && listRef.current.scrollToOffset({ offset: info.averageItemLength * info.index, animated: true }), 120); }}
        initialNumToRender={4}
        windowSize={9}
        showsVerticalScrollIndicator={false}
      />
      {/* reading progress */}
      <View pointerEvents="none" style={[styles.progressTrack, { top: 0, height: insets.top + 4 }]}>
        <Animated.View style={[styles.progress, { width: progress.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }) }]}>
          <LinearGradient colors={['#F47B36', '#E94F91', '#7657D6', '#087F78']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ height: 4, position: 'absolute', bottom: 0, left: 0, right: 0 }} />
        </Animated.View>
      </View>
      <BackFab onPress={() => navigation.goBack()} top={insets.top + 10} />
      <Pressable onPress={() => { bookmarks.toggle(article); toast.show(saved ? 'Removed from saved' : 'Article saved'); }} accessibilityRole="button" accessibilityLabel={saved ? 'Remove bookmark' : 'Save article'} style={[styles.fab, { right: 16, top: insets.top + 10 }]}>
        <Ionicons name={saved ? 'bookmark' : 'bookmark-outline'} size={22} color="#fff" />
      </Pressable>
      <Pressable onPress={shareMore} accessibilityRole="button" accessibilityLabel="Share article" style={[styles.fab, { right: 68, top: insets.top + 10 }]}>
        <Ionicons name="share-social-outline" size={22} color="#fff" />
      </Pressable>
    </View>
  );
}

function BackFab({ onPress, top }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel="Back" style={[styles.fab, { left: 16, top }]}>
      <Ionicons name="arrow-back" size={22} color="#fff" />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  hero: { minHeight: 520, justifyContent: 'flex-end', backgroundColor: colors.navy },
  heroIn: { paddingHorizontal: 20, paddingBottom: 46 },
  cat: { alignSelf: 'flex-start', borderRadius: 999, paddingHorizontal: 15, paddingVertical: 7 },
  catText: { color: '#fff', fontWeight: '800', fontSize: 13 },
  title: { color: '#fff', fontSize: 34, fontWeight: '800', lineHeight: 40, letterSpacing: -0.8, marginTop: 16 },
  excerpt: { color: '#E3ECFA', fontSize: 16.5, lineHeight: 24, marginTop: 12 },
  byline: { flexDirection: 'row', alignItems: 'center', marginTop: 22 },
  av: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: 'rgba(255,255,255,.7)' },
  avText: { color: '#fff', fontWeight: '800' },
  author: { color: '#fff', fontWeight: '800', fontSize: 15 },
  date: { color: '#CFDBF1', fontSize: 13, marginTop: 1 },
  pill: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,.18)', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 7, borderWidth: 1, borderColor: 'rgba(255,255,255,.3)' },
  pillText: { color: '#fff', fontWeight: '700', fontSize: 12.5, marginLeft: 5 },
  toc: { marginHorizontal: 14, marginTop: -26, backgroundColor: '#fff', borderRadius: 22, paddingVertical: 12 },
  tocLabel: { color: colors.muted, fontWeight: '700', fontSize: 13, marginRight: 10 },
  tocChip: { borderRadius: 999, paddingHorizontal: 14, paddingVertical: 8, marginRight: 8, maxWidth: 230 },
  tocText: { fontWeight: '700', fontSize: 13.5 },
  fab: { position: 'absolute', width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(20,43,89,.55)', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,.35)' },
  progressTrack: { position: 'absolute', left: 0, right: 0, overflow: 'hidden' },
  progress: { height: '100%' },
  share: { marginHorizontal: 14, backgroundColor: '#fff', borderRadius: radius.xl, padding: 22 },
  shareTitle: { color: colors.navy, fontSize: 22, fontWeight: '800', textAlign: 'center' },
  shareSub: { color: colors.muted, textAlign: 'center', marginTop: 6 },
  note: { margin: 14, backgroundColor: colors.softNavy, borderRadius: 18, padding: 16 },
  noteText: { color: colors.muted, fontSize: 13.5, lineHeight: 20 },
  relTitle: { color: colors.navy, fontSize: 24, fontWeight: '800', letterSpacing: -0.5, paddingHorizontal: 20, marginBottom: 14 },
  card0: { padding: 30 }
});
