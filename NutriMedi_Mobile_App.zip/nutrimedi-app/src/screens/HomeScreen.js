import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { FlatList, Image, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ArticleCard, FeaturedCard } from '../components/ArticleCard';
import { ProductCard } from '../components/ProductCard';
import { Btn, Screen, SearchBar, SectionHeader, Skeleton, useToast } from '../components/UI';
import { useData } from '../context/DataContext';
import { useCart } from '../context/CartContext';
import { colors, gradients, radius, shadow, themes } from '../theme';
import { catTheme } from '../utils/articleFormat';
import { SLOTS } from '../config';

const logo = require('../../assets/icon.png');

export default function HomeScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const { articles, products, loadArticles, loadProducts } = useData();
  const cart = useCart();
  const toast = useToast();
  const [q, setQ] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { loadArticles(); loadProducts(); }, [loadArticles, loadProducts]);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([loadArticles(true), loadProducts(true)]);
    setRefreshing(false);
  }, [loadArticles, loadProducts]);

  const items = articles.items;
  const featured = items[0];
  const latest = items.slice(1, 5);
  const topics = useMemo(() => {
    const c = {};
    items.forEach((a) => { if (a.category) c[a.category] = (c[a.category] || 0) + 1; });
    return Object.keys(c).sort((x, y) => c[y] - c[x] || x.localeCompare(y)).slice(0, 8).map((k) => ({ name: k, count: c[k] }));
  }, [items]);
  const shop = products.items.slice(0, 6);

  const openArticle = (a) => navigation.navigate('Article', { slug: a.slug, preview: a });
  const submitSearch = () => navigation.navigate('Articles', { q: q.trim() });

  const header = (
    <LinearGradient colors={['#142B59', '#1A3F73', '#087F78']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[styles.hero, { paddingTop: insets.top + 12 }]}>
      <View style={styles.blobA} /><View style={styles.blobB} />
      <View style={styles.topRow}>
        <View style={styles.brand}>
          <Image source={logo} style={styles.logo} accessibilityIgnoresInvertColors />
          <View><Text style={styles.brandName}>NutriMedi</Text><Text style={styles.brandTag}>Better Nutrition. Healthier Living.</Text></View>
        </View>
        <View style={{ flexDirection: 'row' }}>
          <Pressable onPress={() => navigation.navigate('Cart')} hitSlop={8} accessibilityRole="button" accessibilityLabel={`Cart, ${cart.count} items`} style={styles.iconBtn}>
            <Ionicons name="bag-handle-outline" size={22} color="#fff" />
            {cart.count > 0 ? <View style={styles.dot}><Text style={styles.dotText}>{cart.count}</Text></View> : null}
          </Pressable>
          <Pressable onPress={() => navigation.navigate('More')} hitSlop={8} accessibilityRole="button" accessibilityLabel="Open menu" style={[styles.iconBtn, { marginLeft: 8 }]}>
            <Ionicons name="menu" size={24} color="#fff" />
          </Pressable>
        </View>
      </View>
      <Text style={styles.welcome}>Welcome 👋</Text>
      <Text style={styles.h1}>Personalised nutrition care, <Text style={{ color: '#FFB98A' }}>made accessible.</Text></Text>
      <Text style={styles.lead}>Read, book and shop — all in one place.</Text>
      <SearchBar value={q} onChangeText={setQ} placeholder="Search nutrition articles…" style={{ marginTop: 18 }} />
      {q.trim() ? <Btn title={`Search “${q.trim()}”`} onPress={submitSearch} variant="warm" small style={{ marginTop: 12 }} /> : null}
      <View style={styles.cta}>
        <Btn title="Book appointment" icon="calendar" onPress={() => navigation.navigate('Appointment')} style={{ flex: 1 }} small />
        <Btn title="Read articles" icon="book" onPress={() => navigation.navigate('Articles')} variant="light" style={{ flex: 1, marginLeft: 10 }} small />
      </View>
    </LinearGradient>
  );

  return (
    <Screen onRefresh={refresh} refreshing={refreshing} header={header} bottomPad={110}>
      {/* Featured */}
      {articles.loading && !items.length ? (
        <View style={{ padding: 20 }}><Skeleton height={380} radiusPx={30} /></View>
      ) : featured ? (
        <>
          <SectionHeader title="Featured article" subtitle="Our newest read" />
          <View style={{ paddingHorizontal: 16 }}><FeaturedCard a={featured} onPress={() => openArticle(featured)} /></View>
        </>
      ) : articles.error ? (
        <Text style={styles.soft}>Articles could not be loaded. Pull down to try again.</Text>
      ) : null}

      {/* Topics from real categories */}
      {topics.length > 0 ? (
        <>
          <SectionHeader title="Popular topics" subtitle="Explore by category" />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16 }}>
            {topics.map((t) => {
              const th = themes[catTheme(t.name)];
              return (
                <Pressable key={t.name} onPress={() => navigation.navigate('Articles', { category: t.name })} accessibilityRole="button" style={[styles.topic, shadow.sm]}>
                  <LinearGradient colors={th.grad} style={styles.topicIcon}><Ionicons name="leaf" size={20} color="#fff" /></LinearGradient>
                  <Text numberOfLines={1} style={styles.topicName}>{t.name}</Text>
                  <Text style={styles.topicCount}>{t.count} {t.count === 1 ? 'article' : 'articles'}</Text>
                </Pressable>
              );
            })}
          </ScrollView>
        </>
      ) : null}

      {/* Appointment shortcut */}
      <SectionHeader title="Book a consultation" subtitle="Online or in person · booking fee ₹10" />
      <Pressable onPress={() => navigation.navigate('Appointment')} accessibilityRole="button" accessibilityLabel="Book an appointment" style={{ marginHorizontal: 16 }}>
        <LinearGradient colors={gradients.cool} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[styles.appt, shadow.lg]}>
          {SLOTS.map((s) => (
            <View key={s.id} style={styles.slot}>
              <View style={styles.slotIcon}><Ionicons name={s.icon} size={24} color={colors.orange} /></View>
              <View style={{ flex: 1 }}>
                <Text style={styles.slotTitle}>{s.title}</Text>
                <Text style={styles.slotSub}>{s.time} · {s.serials}</Text>
              </View>
            </View>
          ))}
          <View style={styles.apptBtn}><Text style={styles.apptBtnText}>Reserve your slot</Text><Ionicons name="arrow-forward" size={18} color={colors.navy} /></View>
        </LinearGradient>
      </Pressable>

      {/* Latest */}
      {latest.length > 0 ? (
        <>
          <SectionHeader title="Latest articles" action="See all" onAction={() => navigation.navigate('Articles')} />
          <View style={{ paddingHorizontal: 16, gap: 18 }}>
            {latest.map((a) => <ArticleCard key={a.slug} a={a} onPress={() => openArticle(a)} />)}
          </View>
        </>
      ) : null}

      {/* Store */}
      {shop.length > 0 ? (
        <>
          <SectionHeader title="From the store" action="Browse" onAction={() => navigation.navigate('Store')} />
          <FlatList
            horizontal
            data={shop}
            keyExtractor={(p) => p.id}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 6 }}
            ItemSeparatorComponent={() => <View style={{ width: 14 }} />}
            renderItem={({ item }) => (
              <View style={{ width: 178 }}>
                <ProductCard p={item} onPress={() => navigation.navigate('Product', { id: item.id })} onAdd={() => { cart.add(item); toast.show('Added to cart'); }} />
              </View>
            )}
          />
        </>
      ) : null}

      <View style={styles.footer}>
        <Text style={styles.footerText}>Nutrition and wellness information is not a substitute for licensed medical diagnosis or emergency care.</Text>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  hero: { paddingHorizontal: 18, paddingBottom: 26, borderBottomLeftRadius: 34, borderBottomRightRadius: 34, overflow: 'hidden' },
  blobA: { position: 'absolute', right: -70, top: -60, width: 230, height: 230, borderRadius: 115, backgroundColor: 'rgba(233,79,145,.5)' },
  blobB: { position: 'absolute', left: -40, bottom: -90, width: 220, height: 220, borderRadius: 110, backgroundColor: 'rgba(244,123,54,.42)' },
  topRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  brand: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  logo: { width: 44, height: 44, borderRadius: 14, marginRight: 10, backgroundColor: '#fff' },
  brandName: { color: '#fff', fontSize: 20, fontWeight: '800', letterSpacing: -0.4 },
  brandTag: { color: '#9CE9E0', fontSize: 11, fontWeight: '600', marginTop: 1 },
  iconBtn: { width: 44, height: 44, borderRadius: 14, backgroundColor: 'rgba(255,255,255,.16)', alignItems: 'center', justifyContent: 'center' },
  dot: { position: 'absolute', right: -4, top: -4, minWidth: 20, height: 20, borderRadius: 10, backgroundColor: colors.orange, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5 },
  dotText: { color: '#fff', fontWeight: '800', fontSize: 11 },
  welcome: { color: '#BFE9E5', fontWeight: '700', marginTop: 22, fontSize: 14 },
  h1: { color: '#fff', fontSize: 31, lineHeight: 37, fontWeight: '800', letterSpacing: -0.8, marginTop: 6 },
  lead: { color: '#D6E3F4', fontSize: 15, marginTop: 8 },
  cta: { flexDirection: 'row', marginTop: 16 },
  soft: { color: colors.muted, textAlign: 'center', padding: 24 },
  topic: { width: 136, backgroundColor: '#fff', borderRadius: radius.lg, padding: 14, marginRight: 12 },
  topicIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  topicName: { color: colors.navy, fontWeight: '800', fontSize: 15 },
  topicCount: { color: colors.muted, fontSize: 12.5, marginTop: 2 },
  appt: { borderRadius: radius.xl, padding: 18, gap: 12 },
  slot: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,.16)', borderRadius: 20, padding: 14, borderWidth: 1, borderColor: 'rgba(255,255,255,.28)' },
  slotIcon: { width: 48, height: 48, borderRadius: 15, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', marginRight: 14 },
  slotTitle: { color: '#fff', fontSize: 17, fontWeight: '800' },
  slotSub: { color: '#E4ECFB', fontSize: 13, marginTop: 2 },
  apptBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 999, paddingVertical: 14, marginTop: 4 },
  apptBtnText: { color: colors.navy, fontWeight: '800', fontSize: 15.5, marginRight: 8 },
  footer: { padding: 26 },
  footerText: { color: colors.muted, fontSize: 12.5, lineHeight: 18, textAlign: 'center' }
});
